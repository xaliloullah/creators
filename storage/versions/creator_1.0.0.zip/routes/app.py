from app.creator import Creator
from app.controllers.TestController import TestController 

from app.controllers.auth.LoginController import LoginController 
from app.controllers.auth.RegisterController import RegisterController 

Creator.route.add("/", Creator.view.extend('console.home')(
    Creator.view.section('title','Acceuil')(
        Creator.view.section('content')(
            lambda: Creator.view('console.pages.main')
            )
        )
    ), "home")
 

Creator.route.resource("tests", TestController)


Creator.route.add('/login', LoginController.create,'login')
Creator.route.add('/login/store', LoginController.store,'login.store')
Creator.route.add('/register', RegisterController.create,'register')
Creator.route.add('/register/store', RegisterController.store,'register.store')

 