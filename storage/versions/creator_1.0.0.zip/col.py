class Collection:
    def __init__(self, data=None): 
        if data is None:
            self.items = []  
        elif isinstance(data, (list, tuple)):
            self.items = list(data)  
        elif isinstance(data, dict):
            self.items = [data]  
        else:
            raise TypeError("Type de données non pris en charge")

    def add(self, item): 
        self.items.append(item)

    def all(self): 
        return self.items

    def find(self, **kwargs): 
        results = []
        for item in self.items:
            if isinstance(item, dict):
                if all(item.get(k) == v for k, v in kwargs.items()):
                    results.append(item)
        return results

    def delete(self, **kwargs): 
        self.items = [item for item in self.items if not all(item.get(k) == v for k, v in kwargs.items())]

    def update(self, criteria, updates): 
        for item in self.items:
            if isinstance(item, dict) and all(item.get(k) == v for k, v in criteria.items()):
                item.update(updates)
                
                
    def merge(self, other): 
        self.items.extend(other)
        return self

    def first(self, func = None): 
        if func:
            for item in self.items:
                if func(item):
                    return item
        return self.items[0] if self.items else None

    def last(self, func= None): 
        if func:
            for item in reversed(self.items):
                if func(item):
                    return item
        return self.items[-1] if self.items else None

    def sort(self, key = None, reverse: bool = False) -> 'Collection':
        """Trie les éléments."""
        self.items.sort(key=key, reverse=reverse)
        return self

    def reverse(self) -> 'Collection':
        """Inverse l'ordre des éléments."""
        self.items.reverse()
        return self

# Exemple d'utilisation
if __name__ == "__main__":
    # Initialisation avec une liste de dictionnaires
    users = Collection([
        {"id": 1, "name": "Alice"},
        {"id": 2, "name": "Bob"}
    ])

    # Ajouter un nouvel utilisateur
    users.add({"id": 3, "name": "Charlie"})

    # Récupérer tous les utilisateurs
    print("Tous les utilisateurs:", users.all())

    # Rechercher un utilisateur par critère
    print("Utilisateur avec id=2:", users.find(name="Bob"))

    # Mettre à jour un utilisateur
    users.update({"id": 2}, {"name": "Bobby"})
    print("Après mise à jour:", users.all())

    # Supprimer un utilisateur
    users.delete(id=1)
    print("Après suppression:", users.all())
