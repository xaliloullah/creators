# Changelog

## [Unreleased]
- Ajouté : Fonctionnalité X
- Modifié : Amélioration de la performance de Y
- Corrigé : Bug dans Z

## [1.0.1] - 2023-10-01
### Ajouté
- Documentation mise à jour
- Nouveaux tests unitaires

### Modifié
- Optimisation du code pour la fonction A

### Corrigé
- Correction d'un bug mineur dans la fonction B

## [1.0.0] - 2023-09-15
### Ajouté
- Première version du projet
- Fonctionnalité de base A
- Fonctionnalité de base B

### Modifié
- N/A

### Corrigé
- N/A
