├── .env
├── app
│   ├── controllers
│   │   ├── auth
│   │   │   ├── AuthenticatedSessionController.py
│   │   │   └── RegisteredUserController.py
│   │   ├── CategorieController.py
│   │   ├── produit_controller.py
│   │   ├── TestController.py
│   │   └── UserController.py
│   ├── creator.py
│   └── models
│       ├── categorie.py
│       ├── produit.py
│       ├── test.py
│       └── user.py
├── config
│   ├── app.py
│   ├── database.py
│   ├── log.py
│   └── session.py
├── creator
├── databases
│   ├── creators.db
│   └── migrations
│       ├── 2024_10_07_create_categories_table.py
│       ├── 2024_10_07_create_produits_table.py
│       ├── 2024_12_10_create_tests_table.py
│       ├── 2024_12_12_create_sadsads_table.py
│       └── 2024_12_23_create_users_table.py
├── docs
│   └── ARCHITECTURE.md
├── main.py
├── public
│   ├── .htaccess
│   ├── assets
│   │   ├── css
│   │   │   ├── creators.css
│   │   │   └── style.css
│   │   └── images
│   │       └── logo
│   │           ├── favicon.ico
│   │           └── logo.png
│   ├── index.html
│   └── main.py
├── README.md
├── requirements.json
├── resources
│   └── views
│       ├── app
│       │   └── index.cre
│       ├── console
│       │   ├── auth
│       │   ├── components
│       │   │   └── alert.cre
│       │   ├── home.cre
│       │   ├── includes
│       │   │   ├── footer.cre
│       │   │   └── header.cre
│       │   ├── index.cre
│       │   └── pages
│       │       ├── main.cre
│       │       └── test
│       │           ├── create.cre
│       │           ├── edit.cre
│       │           ├── index.cre
│       │           └── view.cre
│       └── web
├── routes
│   ├── app.py
│   ├── auth.py
│   └── route.py
├── storage
│   ├── backups
│   │   ├── backup_20241219_000748.zip
│   │   ├── backup_20241219_004801.zip
│   │   ├── backup_20241221_013225.zip
│   │   └── backup_20241224_005025.zip
│   ├── logs
│   │   └── creators.log
│   ├── private
│   ├── public
│   ├── sessions
│   │   ├── 02a63b31-7274-42be-acd5-9fa8b09edfaf
│   │   ├── 14222cb9-e55a-439d-bf23-33017ae0cb0e
│   │   ├── 1512947b-1be6-4ffd-96dd-75e93e309cc0
│   │   ├── 26682a98-6310-400c-9761-b8004c634a9c
│   │   ├── 284f9c7a-35ff-44db-9cf0-891273f3d8ef
│   │   ├── 28e7bab5-3302-4865-bcaf-b6b2147c6d7a
│   │   ├── 32c339fb-60f3-4f35-9243-d32c396a2cda
│   │   ├── 36b80dcf-aeea-48f8-8f8a-64a7bac1490c
│   │   ├── 3840ca55-fc4c-4a68-961b-7bae7e6636f2
│   │   ├── 3cef902d-ed85-4e9f-ae38-21978cf1e599
│   │   ├── 51b33164-0d4a-48f5-bc92-73643f07f94f
│   │   ├── 56f52fdd-0c76-4a15-836b-96585e2e22de
│   │   ├── 59368832-a060-43b8-bb60-c69199ce0e79
│   │   ├── 8a9a2d2f-d6e2-4e9e-9832-3c90ca14ffa6
│   │   ├── 92064cf1-517c-4197-997e-53002dc4f556
│   │   ├── 9b8541f5-cf8d-4de4-aeb1-aa0e03a01d25
│   │   ├── a407c130-25b3-46d6-9907-dc85e8687c18
│   │   ├── a6f74b02-c04a-43ee-9e65-f8e04023dd2b
│   │   ├── b69b7903-95ae-4a3b-b4a8-5fe25f04ff70
│   │   ├── dc29eee3-b5c8-4555-aad6-b3f56e8c2993
│   │   └── f7772a1b-1615-4a8b-9b1e-849b50c21e3d
│   └── versions
│       └── creator_1.0.0.zip
├── tests
│   ├── ...py
│   ├── .py
│   ├── collection.py
│   ├── controllers
│   │   └── userController.py
│   ├── important.py
│   ├── requests
│   │   ├── application.py
│   │   ├── di.py
│   │   ├── main.py
│   │   ├── old.route.py
│   │   ├── request.py
│   │   ├── route.py
│   │   ├── router.py
│   │   └── server.py
│   ├── style.kv
│   ├── test.cre
│   ├── test.json
│   ├── test.py
│   └── testsocket
│       ├── client.py
│       └── server.py
└── utils
    ├── api
    └── creator
        ├── .env.example
        ├── CHANGELOG.md
        └── src
            ├── app
            │   ├── configs
            │   │   ├── configs.py
            │   │   ├── routes.py
            │   │   ├── settings.json
            │   │   ├── settings.py
            │   │   └── version.py
            │   └── creator.py
            ├── auth
            │   └── auth.py
            ├── command
            │   ├── builder.py
            │   └── command.py
            ├── config
            │   └── setup.py
            ├── console
            │   ├── console.py
            │   └── terminal.py
            ├── controllers
            │   └── controller.py
            ├── core
            │   ├── command.py
            │   ├── crypt.py
            │   ├── date.py
            │   ├── debug.py
            │   ├── exception.py
            │   ├── file.py
            │   ├── handler.py
            │   ├── hash.py
            │   ├── injector.py
            │   ├── response.py
            │   ├── setup.py
            │   ├── task.py
            │   ├── translator.py
            │   └── view.py
            ├── databases
            │   ├── collection.py
            │   ├── connectors
            │   │   ├── connector.py
            │   │   ├── file_db.py
            │   │   ├── mogo_db.py
            │   │   ├── mysql_db.py
            │   │   ├── posgreSQL.py
            │   │   └── sqlite.py
            │   ├── database.py
            │   ├── migration.py
            │   ├── query.py
            │   ├── relation.py
            │   └── schema
            │       ├── column.py
            │       └── table.py
            ├── environment
            │   └── env.py
            ├── middlewares
            │   └── middleware.py
            ├── models
            │   └── model.py
            ├── requests
            │   ├── cookies.py
            │   ├── request.py
            │   ├── requests.py
            │   ├── response.py
            │   ├── sessions.py
            │   └── validator.py
            ├── routes
            │   ├── app.py
            │   ├── route.py
            │   ├── router.py
            │   └── web.py
            ├── servers
            │   ├── clients
            │   │   └── client.py
            │   └── server.py
            └── views
                ├── app
                │   ├── application.py
                │   └── components
                │       ├── confirmation.py
                │       └── pages.py
                ├── app.py
                └── web
                    ├── template.html
                    └── template.py
