class Builder:
    @staticmethod
    def model(name: str, table: str):
        code = f"""from utils.creator.src.models.model import Model

class {name.capitalize()}(Model):
    def __init__(self):
        self.table = '{table}'
        super().__init__(self.table)
        # 
"""
        return code
    
    
    @staticmethod
    def controller(name: str, model, resource: bool):
        code = f"""from utils.creator.src.requests.request import Request
from utils.creator.src.core.view import View \n""" 
        
        if model:
            code += f"""from app.models.{str(model).lower()} import {str(model).capitalize()}\n"""
         
        code += f"""\nclass {name}:\n"""
         
        if resource:
            code += f"""
    @staticmethod
    def index():
        #
        return

    @staticmethod
    def create():
        #
        return

    @staticmethod
    def store(request: Request):
        #
        return

    @staticmethod
    def edit(id):
        #
        return

    @staticmethod
    def update(request: Request, id):
        #
        return

    @staticmethod
    def show(id):
        #
        return

    @staticmethod
    def destroy(id):
        #
        return
    """ 
        else:
            code += f"""    pass\n"""

        return code


    @staticmethod
    def migration(name: str):
        code = f"""from utils.creator.src.databases.schema.table import Table


# Up function for {name} table
def up():
    table = Table('{name}')
    table.id()
    #
    table.timestamps()
    table.create()


# Down function for {name} table
def down():
    table = Table('{name}')
    table.drop()
"""
        return code
    
    @staticmethod
    def middleware(name: str, table: str):
        code = f"""from utils.creator.src.middlewares.middleware import Middleware

class {name}(Middleware):
    def __init__(self):
        self.table = '{table}'
        super().__init__(self.table)
        # 
"""
        return code