from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout

class Page(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Bienvenue sur la page 2"))
        self.setLayout(layout)
