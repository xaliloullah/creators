from PyQt5.QtWidgets import QApplication

from utils.creator.src.views.app import Window
from utils.creator.src.console.console import Console

from utils.creator.src.core.handler import *

class Application:
    def __init__(self): 
        pass
        
    def app(self):
        self._app = QApplication(sys.argv)
        self._window = Window()
        self._window.show()
        sys.exit(self._app.exec_()) 
        
    def console(self):
        self._console = Console()
        self._console.run()
        
    def web(self):
        print("web ...")
        
    def main(self):
        app_mode = app['mode'] 
        if app_mode == "console":
            self.console()
        elif app_mode =="app":
            self.app()
        elif app_mode =="web":
            self.web()
        else:
            handler().error(f"Invalid app mode: {app_mode}. Valid modes are 'console', 'app' or 'web'.")
            exit()
            
        
    