from routes.app import *

def confirmation(arg, yes,no):
    confirm = input(f"{arg} ({yes}/{no}) : ")
    if confirm.lower() == no:
        back() 