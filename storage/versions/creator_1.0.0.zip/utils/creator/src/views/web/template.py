import re

class SimpleTemplate:
    def __init__(self, template_str):
        self.template_str = template_str

    @classmethod
    def from_file(cls, file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            template_str = file.read()
        return cls(template_str)

    def render(self, context):
        # Remplacer les variables
        output = self.template_str
        for key, value in context.items():
            output = output.replace('{{ ' + key + ' }}', str(value))

        # Gérer les boucles
        output = self.render_loops(output, context)

        # Gérer les conditions
        output = self.render_conditions(output, context)

        return output

    def render_loops(self, output, context):
        loop_pattern = r'{% for (\w+) in (\w+) %}(.*?){% endfor %}'
        while re.search(loop_pattern, output, re.DOTALL):
            output = re.sub(loop_pattern, self._loop_replacer, output, flags=re.DOTALL)
        return output

    def _loop_replacer(self, match):
        variable = match.group(1)
        collection = match.group(2)
        content = match.group(3)

        if collection not in context:
            return ''  # Si la collection n'existe pas, ne rien remplacer

        result = ''
        for item in context[collection]:
            result += content.replace('{{ ' + variable + ' }}', str(item))
        return result

    def render_conditions(self, output, context):
        condition_pattern = r'{% if (\w+) %}(.*?)({% else %}(.*?){% endif %}|{% endif %})'
        while re.search(condition_pattern, output, re.DOTALL):
            output = re.sub(condition_pattern, self._condition_replacer, output, flags=re.DOTALL)
        return output

    def _condition_replacer(self, match):
        variable = match.group(1)
        true_content = match.group(2)
        false_content = match.group(4) if match.group(3) else ''

        if variable in context and context[variable]:
            return true_content
        else:
            return false_content

# Exemple d'utilisation
if __name__ == "__main__":
    context = {
        'title': 'Liste d\'éléments',
        'items': ['Élément 1', 'Élément 2', 'Élément 3'],
        'show_message': True,
    }

    # Charger le modèle HTML à partir du fichier
    template = SimpleTemplate.from_file('template.html')
    rendered_html = template.render(context)

    # Afficher le HTML rendu (ou l'enregistrer dans un fichier)
    print(rendered_html)
