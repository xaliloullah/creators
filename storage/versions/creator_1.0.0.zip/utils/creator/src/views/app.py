from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QFrame, QPushButton, QLabel, QLineEdit, QComboBox, QProgressBar, QDialog, QDialogButtonBox, QRadioButton, QCheckBox, QSpinBox, QSlider, QMenuBar, QMenu
from PyQt5.QtGui import QIcon, QCursor
from PyQt5.QtCore import Qt

from routes.app import *

class Window(QMainWindow):
    def __init__(self):
        super().__init__() 
        self.setUI() 
    
    def setTitle(self,title:str):
        self.setWindowTitle(title)
        
    def setSize(self,width,height):
        self.resize(width, height)

    def setStyle(self,style = None): 
        with open(style, "r") as f:
            self.setStyleSheet(f.read())
            
    def setIcon(self,icon = None):
        self.setWindowIcon(QIcon(icon))
        
        
    def resizeEvent(self, event):
        """Détecte les changements de taille de la fenêtre."""
        self.resize_widgets()
        super().resizeEvent(event)
        
    def resize_widgets(self):
        """Redimensionne et déplace les widgets en fonction de la taille de la fenêtre."""
        width = self.width()
        height = self.height()

    def setUI(self):
        self.setTitle(section('title'))
        self.setSize(1000, 800)
        # self.setIcon(icon)
        self.setStyle(asset_path("css/style.css")) 
        Route.route("/")
        
        # Menu bar
        menubar = self.menuBar()
        file_menu = menubar.addMenu('Fichier')
        help_menu = menubar.addMenu('Aide')

        new_action = file_menu.addAction('Nouveau')
        open_action = file_menu.addAction('Ouvrir')
        quit_action = file_menu.addAction('Quitter')
        quit_action.triggered.connect(self.close)

        about_action = help_menu.addAction('À propos')
        self.home()
        
    def home(self):
        """Configure les éléments de l'interface utilisateur"""
        body = QWidget(self)
        body.setProperty("class", "body")
        self.setCentralWidget(body) 

        

        # Card 1 with Label
        card1 = QFrame(body)
        card1.setProperty("class", "card")
        card1.setGeometry(20, 20, 560, 100)

        label1 = QLabel('Bienvenue dans l\'application', card1)
        label1.setProperty("class", "card-title")
        label1.move(20, 20)

        # Card 2 with Button
        card2 = QFrame(body)
        card2.setProperty("class", "card")
        card2.setGeometry(20, 140, 560, 100)

        button1 = QPushButton('Next page', card2)
        button1.move(20, 20)
        button1.setCursor(QCursor(Qt.PointingHandCursor))
        button1.setProperty("class", "btn btn-outline-primary")
        button1.clicked.connect(self.home2)

        # Input Form with QLineEdit
        form = QFrame(body)
        form.setProperty("class", "bg-warning")
        form.setGeometry(20, 260, 560, 200)

        label = QLabel('Entrez votre nom:', form)
        label.setProperty("class","label text-danger")
        label.move(20, 20)
        
        input = QLineEdit(form)
        input.setProperty("class","input")
        input.move(20, 40)

        # Dropdown Menu (QComboBox)
        dropdown = QComboBox(form)
        dropdown.move(20, 100)
        dropdown.setProperty("class","dropdown")
        dropdown.addItems(['Option 1', 'Option 2', 'Option 3'])

        # Progress Bar
        progress_card = QFrame(body)
        progress_card.setProperty("class", "card")
        progress_card.setGeometry(20, 480, 560, 100)

        progress = QProgressBar(progress_card)
        progress.move(20, 20)
        progress.setProperty("class","progress-bar progress-bar-warning progress-bar-sm")
        progress.setValue(50)  # Example value

        # Radio Button Example
        radio_card = QFrame(body)
        radio_card.setProperty("class", "card")
        radio_card.setGeometry(600, 20, 180, 100)

        radio_button1 = QRadioButton("Option 1", radio_card)
        radio_button1.setGeometry(20, 20, 100, 20)
        
        radio_button2 = QRadioButton("Option 2", radio_card)
        radio_button2.setGeometry(20, 50, 100, 20)

        # Checkbox Example
        checkbox_card = QFrame(body)
        checkbox_card.setProperty("class", "card")
        checkbox_card.setGeometry(600, 140, 180, 100)

        checkbox = QCheckBox("Accepter les conditions", checkbox_card)
        checkbox.setGeometry(20, 20, 150, 20)

        # SpinBox Example
        spinbox_card = QFrame(body)
        spinbox_card.setProperty("class", "card")
        spinbox_card.setGeometry(600, 260, 180, 100)

        spinbox = QSpinBox(spinbox_card)
        spinbox.move(20, 20)
        spinbox.setProperty("class","input xl")
        spinbox.setRange(1, 100)

        # Slider Example
        slider_card = QFrame(body)
        slider_card.setProperty("class", "card")
        slider_card.setGeometry(600, 380, 180, 100)

        slider = QSlider(Qt.Horizontal, slider_card)
        slider.setGeometry(20, 20, 150, 30)
        slider.setRange(0, 100)
        slider.setValue(50)

        # Modal Dialog Example
        button2 = QPushButton('Ouvrir Modal', body)
        button2.move(600, 500)
        button2.setCursor(QCursor(Qt.PointingHandCursor))
        button2.setProperty("class", "btn btn-danger")
        button2.clicked.connect(self.open_modal)
        
    def home2(self):
        """Configure les éléments de l'interface utilisateur"""
        body = QWidget(self)
        body.setProperty("class", "body")
        self.setCentralWidget(body)  

        # Card 1 with Label
        card = QFrame(body)
        card.setProperty("class", "card")
        card.setGeometry(20, 20, 760, 400)

        label1 = QLabel('Bienvenue dans l\'application', card)
        label1.setProperty("class", "card-title")
        label1.move(20, 20) 

        button1 = QPushButton('Back Page', card)
        button1.move(20, 60)
        button1.setCursor(QCursor(Qt.PointingHandCursor))
        button1.setProperty("class", "btn btn-warning")
        button1.clicked.connect(self.home) 
         
    def open_modal(self):
        modal = QDialog(self)
        modal.setWindowTitle("Modal")
        modal.setGeometry(100, 100, 300, 200)

        label = QLabel('Ceci est un modal', modal)
        label.setGeometry(20, 20, 260, 40)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, modal)
        buttons.setGeometry(20, 100, 260, 40)
        buttons.accepted.connect(modal.accept) 
        buttons.rejected.connect(modal.reject)

        modal.exec_() 

 