from config import database
from utils.creator.src.databases.connectors.sqlite import Sqlite
from utils.creator.src.databases.connectors.mysql_db import MySQL

sqlite = 'sqlite'
mysql = 'mysql'
driver = database.database['db']
connections = database.database['connections']
config = connections[driver]

class Connector:
    @staticmethod
    def connect(): 
        if driver == sqlite:  
            return Sqlite(config)
        elif driver == mysql:
            # require('mysql-connector-python')
            return MySQL(config) 
        else:
            # raise ValueError(handler().error(f"Unsupported database driver"))
            raise Exception(f"Unsupported database driver")
    
    @staticmethod
    def get_database():
        if driver == sqlite: 
            return Sqlite
        elif driver == mysql:
            return MySQL 
        else:
            raise Exception(f"Unsupported database driver")
        
     
 
        
    
