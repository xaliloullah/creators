from utils.creator.src.console.terminal import Terminal

from utils.creator.src.core.file import File
from utils.creator.src.core.task import Task
from utils.creator.src.core.date import Date
from utils.creator.src.core.view import View 
from utils.creator.src.core.http import Http
from utils.creator.src.core.lang import Lang
from utils.creator.src.core.hash import Hash
from utils.creator.src.core.crypt import Crypt
 
from utils.creator.src.app.configs.settings import Settings
from utils.creator.src.app.configs.version import Version

from utils.creator.src.core.injector import Injector 
from utils.creator.src.requests.sessions import Session

from utils.creator.src.routes.app import Route  


# from utils.creator.src.core.handler import Handler
# from utils.creator.src.routes.route import Router 
from utils.creator.src.app.configs import config

class Creator:  
      
    injector = Injector()
    http = Http
    session = Session()
    
    lang = Lang(config.app["lang"])
     
    # executor = Task() 
    
    class route(Route):
        def __init__(self, name, **kwargs): 
            Creator.handle_request(self.route(name, **kwargs))
    
    class terminal(Terminal):
        pass 
    
    class settings(Settings):
        pass 
    
    class task(Task):
        pass 
    
    class file(File):
        pass 
    
    class date(Date):
        pass 
    
    class crypt(Crypt):
        pass
            
    class hash(Hash):
        def __init__(self): 
            super().__init__()
            
    class view(View):
        def __init__(self, path:str=None, *args): 
            super().__init__(path, *args)

    
    @classmethod 
    def start(cls): 
        try:    
            from routes import route
            cls.route("home") 
            
            # response = cls.handle()   
        except Exception as e:
            cls.handle_exception(e)
        
    @classmethod
    def configure(cls, retry=True): 
        try:    
            cls.name = cls.settings.get("name")  
            cls.version = Version(cls.settings.get("version"))   
            cls.key = cls.settings.get("key")
            return cls
        except KeyError as e:    
            if retry:   
                cls.settings.setup()
                return cls.configure(retry=False)
            else:
                raise RuntimeError("Configuration échouée antès une tentative de récupération.") from e
            
      
    @classmethod
    def upgrade(cls): 
        # cls.settings.activate_env()
        # cls.settings.install_requirements()
        cls.settings.set("key", f"{cls.key}") 
        cls.settings.set("version", f"{cls.version}") 
        cls.settings.update()
    
    @classmethod
    def get_mode(cls):
        return cls.mode
    
    @classmethod
    def set_mode(cls, mode:str):
        cls.mode = mode.lower()
        
    
    @classmethod
    def handle_request(cls, handler):
        from utils.creator.src.requests.request import Request  
        from utils.creator.src.requests.validator import Validator
        
        cls.request = Request()
        cls.request.session = cls.session
        cls.request.validator = Validator(cls.request.session)
        # cls.request.session.create()
        
        cls.injector.register(Request, cls.request.new(handler["data"]))  
        if handler:
            try: 
                if handler["params"]:
                    func, args, kwargs = cls.injector.resolve(handler["action"], **handler["params"]) 
                else:
                    func, args, kwargs = cls.injector.resolve(handler["action"])
                    
                cls.view.set_history({"action": func, "args": args, "kwargs": kwargs})
                 
                return func(*args, **kwargs) 
            
            except Exception as e:
                raise Exception(e)
        else:
            raise ValueError(f"No handler found for URL '{handler["url"]}' and method '{handler["method"]}'.")
    
    @classmethod
    def handle_exception(cls, e): 
        raise Exception(cls.terminal.error(f"{str(e)}")) 
    
    # @classmethod
    # def route(cls, name, **params):
    #     url = cls.Route.route(name, **params) 
    #     handler = cls.Route.dispatch(url, **params) 
    #     request = cls.request
    #     request(handler["query"]) 
    #     cls.injector.register(cls.request, request)
    #     if handler:
    #         try: 
    #             if handler["params"]:
    #                 handle = cls.injector.resolve(handler["action"], **handler["params"])
    #             else:
    #                 handle = cls.injector.resolve(handler["action"])
    #             response = handle["action"](*handle["params"], **handle["data"]) 
    #             return response
            
    #         except Exception as e:
    #             raise Exception(e)
    #     else:
    #         raise ValueError(f"No handler found for URL '{handler["url"]}' and method '{handler["method"]}'.") 
    
    # @classmethod
    # def handle(cls):
    #     if cls.mode == "console": 
    #         from utils.creator.src.routes.app import Route 
    #         cls.Route = Route
    #         cls.route("main")
    #     else:
    #         return None  