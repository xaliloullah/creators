#import all routes like config

# from routes.app import *

