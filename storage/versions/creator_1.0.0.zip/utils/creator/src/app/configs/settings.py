from utils.creator.src.core.file import File
from utils.creator.src.core.task import Task
from utils.creator.src.core.date import Date
import os
import sys

class Settings:
    path = "utils/creator/src/app/configs/settings.json" 
    
    @classmethod 
    def update(cls):
        try: 
            cls.settings["updated_at"] = f"{Date.now()}"
            cls.save()
        except Exception as e:
            raise Exception(e) 
        
    @classmethod
    def get(cls, key):
        cls.settings = cls.load()
        return cls.settings[key]
    
    @classmethod
    def set(cls, key, value): 
        cls.settings = cls.load()
        cls.settings[key] = value  
        
    @classmethod
    def load(cls):
        return File.load(cls.path, format="json") 
        
    @classmethod
    def save(cls):
        backup = cls.load()
        try:
            File.save(cls.path, cls.settings, format="json", indent=2)
        except Exception as e:
            File.save(cls.path, backup, format="json", indent=2) 
            raise
         
    @classmethod
    def setup(cls):
        try:  
            cls.settings = cls.load()
            cls.settings["name"] = "creator"
            cls.settings["version"] = "1.0.0"
            cls.settings["author"] = "Ibrahima Khaliloullah Thiam"
            cls.settings["description"] = "creator app"
            cls.settings["app"] = f"{Date.now()}"
            cls.settings["python_requires"] = f"{sys.version.split()[0]}"
            cls.settings["install_requires"] = File.load("requirements.json", format="json")
            cls.settings["created_at"] = f"{Date.now()}"
            cls.settings["updated_at"] = f"{Date.now()}"
            cls.save()
            
        except Exception as e:
            raise Exception(e)
        
   
    
    @staticmethod
    def vscode_setting(path = ".vscode/settings.json"):
        try:  
            settings = File.load(path, format="json")
            
            settings["files.associations"] = {
                "*.cre": "python", 
                "creator": "python"
            } 
            File.save(path, settings, format="json", indent=2)   
        except Exception as e:
            raise Exception(e)
        
    @staticmethod
    def install_requirements(path='requirements.json'):
        requirements = File.load(path, format="json")  
        for package, version in requirements.items():
            # package = value["package"]
            # version = value["version"]
            Task.install(package, version=version)
        
# def creating_resources():
#     path = resources_path()
#     ensure_path_exists(path)
    
    def creating_config(source, destination):
        File.ensure_path_exists(source)
        configs_file = File.list_dir(source, endswith='.py')
        
        content = []
        for config in configs_file:
            content.append(Task.build_import(File.join_path(source, config), "*"))
            
        File.save(destination, "\n".join(content)) 
    
    # def backup(source, destination):
    #     pass
    
    @staticmethod
    def make_architecture(path='docs/ARCHITECTURE.md'):
        File.ensure_path_exists(path) 
        File.save(path, File.make_structure(ignore=['__pycache__', '.vscode']))
        
    @staticmethod
    def create_env(path="utils/creator/src/environment/creator/"):
        try:
            if not File.path_exists(path): 
                Task.execute("venv", path)
                print(f"Environnement virtuel creer à {path}")
        except Exception as e:
            raise Exception(e) 
        
    @staticmethod
    def activate_env(path="utils/creator/src/environment/creator/"): 
        if os.name == 'nt':
            activate_script = File.join_path(path, "Scripts", "activate")
        else:
            activate_script= File.join_path(path, "bin", "activate")
            
        if File.path_exists(activate_script):
            activate_script = File.absolute_path(activate_script)
            if os.name == 'nt':
                os.system(f'cmd /k "{activate_script}"')
            else:
                os.system(f'bash -c "{activate_script}"')
            print(f"Environnement virtuel activé à {path}")
        else: 
            Settings.create_env()
            Settings.activate_env()
            
    # @staticmethod      
    # def deactivate_env(path="utils/creator/src/environment/creator/"):
    #     path = File.absolute_path(path)
    #     deactivate_script = File.join_path(path, "Scripts", "deactivate")  
    #     Task.execute(deactivate_script, script=True) 

        
  