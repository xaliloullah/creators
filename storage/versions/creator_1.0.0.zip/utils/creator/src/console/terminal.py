import os 
import sys

class Terminal: 
    
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    GREY = '\033[90m'
    LIGHT_BLACK = '\033[80m'
    LIGHT_RED = '\033[91m'
    LIGHT_GREEN = '\033[92m'
    LIGHT_YELLOW = '\033[93m'
    LIGHT_BLUE = '\033[94m'
    LIGHT_MAGENTA = '\033[95m'
    LIGHT_CYAN = '\033[96m'
    LIGHT_WHITE = '\033[97m'
            

    # Background colors
    BACKGROUND_BLACK = '\033[40m '
    BACKGROUND_RED = '\033[41m '
    BACKGROUND_GREEN = '\033[42m '
    BACKGROUND_YELLOW = '\033[43m '
    BACKGROUND_BLUE = '\033[44m '
    BACKGROUND_MAGENTA = '\033[45m '
    BACKGROUND_CYAN = '\033[46m '
    BACKGROUND_WHITE = '\033[47m '
    BACKGROUND_GREY = '\033[48m '
    BACKGROUND_LIGHT_BLACK = '\033[100m '
    BACKGROUND_LIGHT_RED = '\033[101m '
    BACKGROUND_LIGHT_GREEN = '\033[102m '
    BACKGROUND_LIGHT_YELLOW = '\033[103m '
    BACKGROUND_LIGHT_BLUE = '\033[104m '
    BACKGROUND_LIGHT_MAGENTA = '\033[105m '
    BACKGROUND_LIGHT_CYAN = '\033[106m '
    BACKGROUND_LIGHT_WHITE = '\033[107m '

            # Text Formatting
    BOLD = '\033[1m'         
    UNDERLINE = '\033[4m'     
    ITALIC = '\033[3m'        
    BLINK = '\033[5m'         
    REVERSE = '\033[7m'       
    HIDDEN = '\033[8m'        
    RESET = '\033[0m'

    # icon
    ICON_LIGHT_CHECK = "✔"
    ICON_LIGHT_ERROR = "✖" 
    ICON_LIGHT_WARNING = "⚠" 
    ICON_LIGHT_INFO = "ℹ"
    ICON_INFO_CIRCLE = "🛈"
    ICON_LIGHT_LOCK = "🗝"
    ICON_ARROW_UP = "🔼"
    ICON_ARROW_DOWN = "🔽"
    ICON_ARROW_RIGHT = "▶"
    ICON_ARROW_LEFT = "◀"
    ICON_CHECK = "✔️"
    ICON_ERROR = "❌"
    ICON_PLUS = "➕"
    ICON_MOIN = "➖"
    ICON_EDIT = "📝"
    ICON_EXCLAMATION = "❗"
    ICON_QUESTION = "❓"
    ICON_STOP = "⛔"
    ICON_WARNING = "⚠️"
    ICON_LIGHTBULB = "💡"
    ICON_LOCK = "🔒"
    ICON_ENVELOPPE = "📧" 
    ICON_NUMBER = "🔢"
    ICON_PHONE = "📞"
    ICON_GLOBE = "🌐"
    ICON_SEARCH = "🔍"
    ICON_CALENDAR = "📅"
    ICON_CARD = "💳"
    ICON_FILE = "📁"
    ICON_LOCATION = "🏠"
    ICON_HEART = "❤️"
    ICON_STAR = "⭐"
    ICON_BELL = "🔔"
    ICON_FIRE = "🔥"
    ICON_GEAR = "⚙️" 
    ICON_CHECKMARK = "✅" 
    ICON_INFO = "ℹ️"
    ICON_THUMBS_UP = "👍"
    ICON_THUMBS_DOWN = "👎"
    ICON_SUN = "☀️"
    ICON_MOON = "🌙"
    ICON_CLOUD = "☁️"
    ICON_RAIN = "🌧️"
    ICON_SNOW = "❄️"
    ICON_MOUNTAIN = "⛰️"
    ICON_TROPHY = "🏆"
    ICON_MEDAL = "🏅"
    ICON_PEACE = "✌️"
    ICON_HEART_EYES = "😍"
    ICON_FIREWORKS = "🎆"
    ICON_GIFT = "🎁"
    ICON_PARTY_POPPER = "🎉"
    ICON_FINGERPOINTING = "👉"
    ICON_SOS = "🆘"
    ICON_FOOTBALL = "⚽"
    ICON_BASKETBALL = "🏀"

    
        
   
    @classmethod            
    def clear(cls):
        return os.system("cls" if os.name == "nt" else "clear")
     
    # color 
    @classmethod     
    def black(cls):
        return cls.BLACK
    
    @classmethod 
    def red(cls):
        return cls.RED
    
    @classmethod 
    def green(cls):
        return cls.GREEN
    
    @classmethod 
    def yellow(cls):
        return cls.YELLOW
    
    @classmethod 
    def blue(cls):
        return cls.BLUE
    
    @classmethod 
    def magenta(cls):
        return cls.MAGENTA
    
    @classmethod 
    def cyan(cls):
        return cls.CYAN
    
    @classmethod 
    def white(cls):
        return cls.WHITE
    
    @classmethod 
    def grey(cls):
        return cls.GREY
    
    @classmethod 
    def light_black(cls):
        return cls.LIGHT_BLACK
    
    @classmethod 
    def light_red(cls):
        return cls.LIGHT_RED
    
    @classmethod 
    def light_green(cls):
        return cls.LIGHT_GREEN
    
    @classmethod 
    def light_yellow(cls):
        return cls.LIGHT_YELLOW
    
    @classmethod 
    def light_blue(cls):
        return cls.LIGHT_BLUE
    
    @classmethod 
    def light_magenta(cls):
        return cls.LIGHT_MAGENTA
    
    @classmethod 
    def light_cyan(cls):
        return cls.LIGHT_CYAN
    
    @classmethod 
    def light(cls):
        return cls.LIGHT_WHITE

    # BACKGROUND
    @classmethod     
    def bg_black(cls):
        return cls.BACKGROUND_BLACK
    
    @classmethod 
    def bg_red(cls):
        return cls.BACKGROUND_RED
    
    @classmethod 
    def bg_green(cls):
        return cls.BACKGROUND_GREEN
    
    @classmethod 
    def bg_yellow(cls):
        return cls.BACKGROUND_YELLOW
    
    @classmethod 
    def bg_blue(cls):
        return cls.BACKGROUND_BLUE
    
    @classmethod 
    def bg_magenta(cls):
        return cls.BACKGROUND_MAGENTA
    
    @classmethod 
    def bg_cyan(cls):
        return cls.BACKGROUND_CYAN
    
    @classmethod 
    def bg_white(cls):
        return cls.BACKGROUND_WHITE
    
    @classmethod 
    def bg_grey(cls):
        return cls.BACKGROUND_GREY
    
    @classmethod 
    def bg_light_black(cls):
        return cls.BACKGROUND_LIGHT_BLACK
    
    @classmethod 
    def bg_light_red(cls):
        return cls.BACKGROUND_LIGHT_RED
    
    @classmethod 
    def bg_light_green(cls):
        return cls.BACKGROUND_LIGHT_GREEN
    
    @classmethod 
    def bg_light_yellow(cls):
        return cls.BACKGROUND_LIGHT_YELLOW
    
    @classmethod 
    def bg_light_blue(cls):
        return cls.BACKGROUND_LIGHT_BLUE
    
    @classmethod 
    def bg_light_magenta(cls):
        return cls.BACKGROUND_LIGHT_MAGENTA
    
    @classmethod 
    def bg_light_cyan(cls):
        return cls.BACKGROUND_LIGHT_CYAN
    
    @classmethod 
    def bg_light(cls):
        return cls.BACKGROUND_LIGHT_WHITE
    
    @classmethod     
    def bold(cls):
        return cls.BOLD
    
    @classmethod     
    def underline(cls):
        return cls.UNDERLINE
    
    @classmethod     
    def italic(cls):
        return cls.ITALIC
    
    @classmethod     
    def blink(cls):
        return cls.BLINK
    
    @classmethod     
    def reverse(cls):
        return cls.REVERSE
    
    @classmethod     
    def hidden(cls):
        return cls.HIDDEN
    
    @classmethod     
    def reset(cls):
        return cls.RESET
    
    @classmethod     
    def icon_light_check(cls):
        return cls.ICON_LIGHT_CHECK
    
    @classmethod 
    def icon_light_error(cls):
        return cls.ICON_LIGHT_ERROR
    
    @classmethod 
    def icon_light_warning(cls):
        return cls.ICON_LIGHT_WARNING
    
    @classmethod 
    def icon_light_info(cls):
        return cls.ICON_LIGHT_INFO
    
    @classmethod 
    def icon_info_circle(cls):
        return cls.ICON_INFO_CIRCLE
    
    @classmethod 
    def icon_light_lock(cls):
        return cls.ICON_LIGHT_LOCK
    
    @classmethod 
    def icon_arrow_up(cls):
        return cls.ICON_ARROW_UP
    
    @classmethod 
    def icon_arrow_down(cls):
        return cls.ICON_ARROW_DOWN
    
    @classmethod 
    def icon_arrow_right(cls):
        return cls.ICON_ARROW_RIGHT
    
    @classmethod 
    def icon_arrow_left(cls):
        return cls.ICON_ARROW_LEFT
    
    @classmethod 
    def icon_check(cls):
        return cls.ICON_CHECK
    
    @classmethod 
    def icon_error(cls):
        return cls.ICON_ERROR
    
    @classmethod 
    def icon_plus(cls):
        return cls.ICON_PLUS
    
    @classmethod 
    def icon_moin(cls):
        return cls.ICON_MOIN
    
    @classmethod 
    def icon_edit(cls):
        return cls.ICON_EDIT
    
    @classmethod 
    def icon_exclamation(cls):
        return cls.ICON_EXCLAMATION
    
    @classmethod 
    def icon_question(cls):
        return cls.ICON_QUESTION
    
    @classmethod 
    def icon_stop(cls):
        return cls.ICON_STOP
    
    @classmethod 
    def icon_warning(cls):
        return cls.ICON_WARNING
    
    @classmethod 
    def icon_lightbulb(cls):
        return cls.ICON_LIGHTBULB
    
    @classmethod 
    def icon_lock(cls):
        return cls.ICON_LOCK
    
    @classmethod 
    def icon_enveloppe(cls):
        return cls.ICON_ENVELOPPE
    
    @classmethod 
    def icon_number(cls):
        return cls.ICON_NUMBER
    
    @classmethod 
    def icon_phone(cls):
        return cls.ICON_PHONE
    
    @classmethod 
    def icon_globe(cls):
        return cls.ICON_GLOBE
    
    @classmethod 
    def icon_search(cls):
        return cls.ICON_SEARCH
    
    @classmethod 
    def icon_calendar(cls):
        return cls.ICON_CALENDAR
    
    @classmethod 
    def icon_card(cls):
        return cls.ICON_CARD
    
    @classmethod 
    def icon_file(cls):
        return cls.ICON_FILE
    
    @classmethod 
    def icon_location(cls):
        return cls.ICON_LOCATION
    
    @classmethod 
    def icon_heart(cls):
        return cls.ICON_HEART
    
    @classmethod 
    def icon_star(cls):
        return cls.ICON_STAR
    
    @classmethod 
    def icon_bell(cls):
        return cls.ICON_BELL
    
    @classmethod 
    def icon_fire(cls):
        return cls.ICON_FIRE
    
    @classmethod 
    def icon_gear(cls):
        return cls.ICON_GEAR
    
    @classmethod 
    def icon_checkmark(cls):
        return cls.ICON_CHECKMARK
    
    @classmethod 
    def icon_info(cls):
        return cls.ICON_INFO
    
    @classmethod 
    def icon_thumbs_up(cls):
        return cls.ICON_THUMBS_UP
    
    @classmethod 
    def icon_thumbs_down(cls):
        return cls.ICON_THUMBS_DOWN
    
    @classmethod 
    def icon_sun(cls):
        return cls.ICON_SUN
    
    @classmethod 
    def icon_moon(cls):
        return cls.ICON_MOON
    
    @classmethod 
    def icon_cloud(cls):
        return cls.ICON_CLOUD
    
    @classmethod 
    def icon_rain(cls):
        return cls.ICON_RAIN
    
    @classmethod 
    def icon_snow(cls):
        return cls.ICON_SNOW
    
    @classmethod 
    def icon_mountain(cls):
        return cls.ICON_MOUNTAIN
    
    @classmethod 
    def icon_trophy(cls):
        return cls.ICON_TROPHY
    
    @classmethod 
    def icon_medal(cls):
        return cls.ICON_MEDAL
    
    @classmethod 
    def icon_peace(cls):
        return cls.ICON_PEACE
    
    @classmethod 
    def icon_heart_eyes(cls):
        return cls.ICON_HEART_EYES
    
    @classmethod 
    def icon_fireworks(cls):
        return cls.ICON_FIREWORKS
    
    @classmethod 
    def icon_gift(cls):
        return cls.ICON_GIFT
    
    @classmethod 
    def icon_party_popper(cls):
        return cls.ICON_PARTY_POPPER
    
    @classmethod 
    def icon_fingerpointing(cls):
        return cls.ICON_FINGERPOINTING
    
    @classmethod     
    def icon_help(cls):
        return cls.ICON_SOS
    
    # -----------------------------------------------------
    
    @classmethod     
    def success(cls, values):
        cls.SUCCESS = f"{cls.icon_check()}  {cls.style('[SUCCESS] : ', cls.bold)}"
        cls.echo(f"{cls.style(cls.SUCCESS, cls.green)}{cls.style(values, cls.green)}")
    
    @classmethod 
    def error(cls, values):
        cls.ERROR = f"{cls.icon_error()} {cls.style('[ERROR] : ', cls.bold)}"
        cls.echo(f"{cls.style(cls.ERROR, cls.light_red)}{cls.style(values, cls.light_red)}")
    
    @classmethod 
    def info(cls, values):
        cls.INFO = f"{cls.icon_info_circle()} {cls.style( '[INFO] : ', cls.bold)}"
        cls.echo(f"{cls.style(cls.INFO, cls.blue)}{cls.style(values, cls.light)}")
    
    @classmethod      
    def warning(cls, values):
        cls.WARNING = f"{cls.icon_warning()}  {cls.style( '[WARNING] : ', cls.bold)}"
        cls.echo(f"{cls.style(cls.WARNING, cls.yellow)}{cls.style(values, cls.yellow)}")
    
    @classmethod 
    def danger(cls, values):
        cls.CRITICAL = f"{cls.icon_stop()} {cls.style('[CRITICAL] : ', cls.bold)}"
        cls.echo(f"{cls.style(cls.CRITICAL, cls.red)}{cls.style(values, cls.red)}")
    
    @classmethod      
    def comment(cls, values):
        cls.COMMENT = f"{cls.icon_info()} "
        cls.echo(f"{cls.style(cls.COMMENT, cls.light)}{cls.style(values, cls.black)}")
    
    @classmethod      
    def description(cls, values):
        cls.echo(f"{cls.style(values, cls.black, cls.italic)}")
    
    @classmethod 
    def question(cls, values):
        cls.QUESTION = f"{cls.style(': ', cls.bold)}{cls.icon_question()}" 
        cls.echo(f"{cls.style(values, cls.light)} {cls.style(cls.QUESTION, cls.grey)}")
    
    @classmethod      
    def debug(cls, values):
        cls.DEBUG = f"{cls.icon_lightbulb()} {cls.style('[DEBUG] : ', cls.bold)}"
        cls.echo(f"{cls.style(cls.DEBUG, cls.black)}{cls.style(values, cls.light)}")
    
    @classmethod      
    def help(cls, values):
        cls.HELP = f"{cls.icon_lightbulb()} {cls.style('[HELP] : ', cls.bold)}" 
        cls.echo(f"{cls.style(cls.HELP, cls.cyan)}{cls.style(values, cls.cyan)}")
    
    
    @classmethod 
    def highlight(cls, values):
        cls.echo(f"{cls.style(values, cls.bold, cls.yellow)}")
    
    @classmethod 
    def muted(cls, values):
        cls.echo(f"{cls.style(values, cls.grey)}")
    
    @classmethod 
    def emphasize(cls, values):
        cls.echo(f"{cls.style(values, cls.italic, cls.green)}")
    
    @classmethod 
    def title(cls, values:str, icon="-",width = 30):
        cls.echo(f"{cls.style(values.center(width, icon), cls.bold, cls.light, cls.underline)}") 
    
    @classmethod      
    def subtle(cls, values):
        cls.echo(f"{cls.style(values, cls.grey)}")
    
    @classmethod      
    def label(cls, values):
        cls.echo(cls.style(values,cls.light))
    
    @classmethod      
    def quote(cls, text, author="Unknown"):
        cls.echo(f"{cls.style('“', cls.green)}{cls.style(text, cls.italic)}{cls.style('”', cls.green)} - {cls.style(author, cls.light)}")

    
    @classmethod      
    def style(cls, values, *styles):
        # print(sys.stdout.isatty()) 

        styles = [style() if callable(style) else str(style) for style in styles]
        return f"{''.join(styles)}{values}{cls.reset()}"
    
    @classmethod      
    def echo(cls, values):
        print(values)
    
    @classmethod      
    def uppercase(cls, values:str):
        cls.echo(cls.style(values.upper(), cls.bold))
    
    @classmethod 
    def lowercase(cls, values):
        cls.echo(cls.style(values.lower(), cls.light))
    
    @classmethod      
    def progress_bar(cls, percentage):
        bar = '█' * int(percentage / 10) + '-' * (10 - int(percentage / 10))
        cls.echo(f"[{bar}] {percentage}%")
    
    @classmethod      
    def ascii_art(cls, art):
        cls.echo(cls.style(art, cls.green))

        
    # import time
    
    @classmethod 
    # def animate(cls, text, speed=0.1):
    #     for char in text:
    #         cls.echo(cls.style(char, cls.light), end='', flush=True)
    #         time.sleep(speed)
    #     cls.echo()  # Pour terminer la ligne
    
    @classmethod     
    def center(cls, values, width=40):
        cls.echo(f"{cls.style(values.center(width), cls.bold)}")
    
    @classmethod      
    def multi_line(cls, lines, separator="-"):
        for line in lines:
            cls.echo(f"{cls.style(line, cls.light)}")
        cls.echo(f"{cls.style(separator * 30, cls.grey)}")
    
    @classmethod      
    def progress_circle(cls, steps, total):
        import sys
        import time
        for i in range(steps):
            progress = (i + 1) / total
            symbols = ['|', '/', '-', '\\']
            sys.stdout.write(f"\r{cls.style(symbols[i % 4], cls.green)} {progress*100:.1f}%")
            sys.stdout.flush()
            time.sleep(0.1)
    
    @classmethod          
    def truncate(cls, text, length=30, suffix="..."):
        if len(text) > length:
            cls.echo(cls.style(text[:length] + suffix, cls.light))
        else:
            cls.echo(cls.style(text, cls.light))

    
    @classmethod 
    def text_to_speech(cls, text):
        import pyttsx3
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()

    
    @classmethod 
    def word_wrap(cls, text, width=50):
        import textwrap
        wrapped_text = textwrap.fill(text, width)
        cls.echo(cls.style(wrapped_text, cls.light))

    
    @classmethod 
    def table(cls, data,**kwargs): 
        """Generates a textual representation of a formatted table.

    valuesuments:
        **kwargs:
            - `data` (list of dict): A list of dictionaries representing table rows.
              E
              @classmethod ach   dictionary contains key-value pairs corresponding to columns 
              (default: empty list).
            - `keys` (list of str): List of keys to display as columns. 
              If None, all keys found in the `data` dictionaries
              @classmethod  ar e used.
            - `margin` (int): Number of spaces between columns (default: 3). 
            @classmethod    
            - `icon` (str): Icon or separator used to draw the table border (default: "-").

    Returns:
        str: A string representing the formatted table.
        """   
        data = list(data)     
        keys = kwargs.get('keys', None)      
        margin = kwargs.get('margin', 3) 
        icon = kwargs.get('icon', "-") 
        if not data:
            cls.warning("Aucune donnée dans la table")
        else: 
            if keys:
                head = keys
            else: 
                head = data[0].keys()  
                   
            def border():
                return (cls.style(icon * (sum(width.values()) + len(width) - (1 + margin)), cls.grey)) 
                
            width = {row: max(len(row), max(len(str(body[row])) for body in data)) + margin for row in head} 
            cls.echo(cls.style(" ".join([f"{row:<{width[row]}}" for row in head]), cls.grey, cls.bold)) 
            cls.echo(border())   
            for body in data:
                cls.echo(cls.style(" ".join([f"{body[row]:<{width[row]}}" for row in head]), cls.light))
            cls.echo(border())   
    
    @classmethod           
    def list(cls, data, **kwargs):
        """Generates a textual representation of a formatted list.

        Arguments:
            **kwargs:
                - `data` (list of dict): A list of dictionaries representing list rows.
                E
                @classmethod ach     dictionary contains key-value pairs corresponding to columns 
                (default: empty list).      
                @classmethod 
                - `margin` (int): Number of spaces between columns (default: 0).  
                @classmethod   
                - `icon` (str): Icon or separator used to draw 
                @classmethod the   list border (default: "-").
                - `color` (str): Color used to style the list (default: "c
                @classmethod yan   ").
                - `numbered` (bool): Whether the list should be numbered (defaul
                @classmethod t:  False).
                - `inline` (bool): Whether the list should be displayed inline (default: False).
        Returns:
            str: A string representing the formatted list.
        """   
        data = list(data)          
        margin = kwargs.get('margin', 0) 
        icon = kwargs.get('icon', "")    
        color = kwargs.get('color', cls.cyan)    
        numbered = kwargs.get('numbered', False) 
        inline = kwargs.get('inline', False) 
            
        if not data:
            cls.warning("Aucune donnée dans la liste")  
        else:
            lists = []
            if numbered:
                for index, item in enumerate(data, start=1):   
                    lists.append(f"{index:<{margin}}. {item}")
            else:
                for item in data: 
                    lists.append(f"{icon:<{margin}}{item}")
 
            if inline:
                cls.echo(cls.style("  ".join(lists), color))
            else:
                for item in lists:
                    cls.echo(cls.style(item, color))

    
    @classmethod                  
    def confirmation(cls, values="...", **kwargs): 
        yes = kwargs.get('yes', 'yes')      
        no = kwargs.get('no', 'no')     
        action = kwargs.get('action', lambda: print("No action defined"))

        confirm = input(f"{values} ({yes}/{no}): ")
        if confirm.lower() == no:
            action()
    
    
    @classmethod      
    def textarea(cls, placehoder="textarea: ", end="\n"):
        print(placehoder, end='', flush=True)
        textarea = []

        while True:
            text = input()
            if text == "":
                if textarea and textarea[-1] == "":
                    break
                else:
                    textarea.append("")
            else:
                textarea.append(text)
                
        output = end.join(textarea)
        if output.endswith(end):
            output = output[:-len(end)]
        return output
    
    
    @classmethod      
    def password(cls, placehoder="password : ", **kwargs):
        import keyboard
        print(placehoder, end='', flush=True)
        password = '' 
        while True:
            event = keyboard.read_event(suppress=True)
            if event.event_type == 'down': 
                char = event.name
                if char == 'enter':
                    print() 
                    break
                elif char == 'backspace':
                    if len(password) > 0:
                        password = password[:-1]
                        print('\b \b', end='', flush=True)
                elif len(char) == 1:
                    password += char
                    print('*', end='', flush=True)
        return password
    
    @classmethod 
    def input(cls, placehoder="", **kwargs):  
         
        value = kwargs.get('value', "")     
        type = kwargs.get('type', 'text')  
        min = kwargs.get('min', 0)  
        max = kwargs.get('max', 100)  
        required = kwargs.get('required', True)  
        
        action = input
        
        if type =="email":
            icon = cls.icon_enveloppe()
            
        elif type == "password": 
            icon = cls.icon_lock()
            action = cls.password
            
        elif type in ("tel", "phone"):
            icon = cls.icon_phone()
            
        elif type == "address":
            icon = cls.icon_location()
            
        elif type == "url":
            icon = cls.icon_globe()
            
        elif type == "search":
            icon = cls.icon_search()
            
        elif type == "date":
            icon = cls.icon_calendar()
            
        elif type == "number":
            icon = cls.icon_number()
            
        elif type in ("textarea","message"):
            icon = cls.icon_file()
            action = cls.textarea
            
        else:
            icon = cls.icon_arrow_right()
            
        return action(f"{cls.style(f"{icon} {placehoder} " , cls.grey)}") or value  
    
    
    
 