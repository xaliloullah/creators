from routes.app import Route

class Console: 
        
    @staticmethod
    def run():    
        url = Route.route("main") 
        handler = Route.dispatch(url) 
        return handler