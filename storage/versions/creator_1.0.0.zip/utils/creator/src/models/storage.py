from utils.creator.src.core.file import File
from utils.creator.src.models.collection import Collection

class Storage: 
    def __init__(self, path: str=None, **kwargs): 
        self.path = path  
        self.format = kwargs.get("format", None) 
        self.data = kwargs.get("data", None)
        
        if not self.format:
            self.format = File.get_extension(self.path, without_dot=True)
        else:
            self.path = File.set_extension(self.path, self.format)
        
 
    def load(self, path = None,**kwargs):
        try:    
            return Collection(File.load(self.path, format=self.format, **kwargs))
        except Exception as e:
            raise Exception(e)
          
    def save(self, **kwargs):  
        backup = self.load()
        try:    
            File.save(self.path, self.data, format=self.format, **kwargs)   
        except Exception as e:
            File.save(self.path, backup, format=self.format)   
            raise Exception(e)
        
    
        
    def __repr__(self):
        return f"{self.__class__.__name__}({self.path}, format={self.format}), data={self.data}"