class Collection:
    
    def __init__(self, *items):   
        if len(items) == 1 and isinstance(items[0], (list, tuple, dict)):
            self.items = items[0]
        else:
            self.items = list(items) 
          

    def all(self):
        return self.items

    def add(self, item):
        self.items.append(item)
        return self

    def remove(self, item):
        self.items = [i for i in self.items if i != item]
        return self
    
    def find(self, key, value):
        for item in self.items:
            if isinstance(item, dict) and item.get(key) == value:
                return item
        return None 
    
    def get(self, key: str=None, default=None): 
        data = self.items  
        if key:
            try: 
                for part in key.split("."):
                    if isinstance(data, dict): 
                        data = data[part]   
                    elif isinstance(data, (list, tuple)):
                        data = data[int(part)]  
                    else:
                        return default
            except Exception as e:
                return default
        return data  
    
    def set(self, key: str, value): 
        part = key.split(".")  
        data = self.items   
        for key in part[:-1]:
            if key not in data:
                data[key] = {}   
            data = data[key] 
        data[part[-1]] = value 
        
    def new(self, items):
        return Collection(*items)
    
    def filter(self, func):
        return Collection(filter(func, self.items))

    def map(self, func):
        return Collection(map(func, self.items))

    def reduce(self, func, initial=None):
        from functools import reduce
        return reduce(func, self.items, initial)

    def first(self, func=None):
        if func:
            for item in self.items:
                if func(item):
                    return item
        return self.items[0] if self.items else None 

    def last(self, func=None):
        if func:
            for item in reversed(self.items):
                if func(item):
                    return item
        return self.items[-1] if self.items else None 

    def where(self, key, value):
        self.items = Collection(item for item in self.items if item.get(key) == value)
        return self

    def sort(self, key=None, reverse=False):
        return Collection(sorted(self.items, key=key, reverse=reverse)) 

    def chunk(self, size):
        return Collection([self.items[i:i + size] for i in range(0, len(self.items), size)]) 
    
    def pluck(self, key):
        return Collection(item.get(key) for item in self.items if isinstance(item, dict)) 
    
    def merge(self, other) -> 'Collection': 
        self.items.extend(other)
        return self
    
    def count(self) -> int: 
        return len(self.items)

    def sum(self, key= None): 
        if key:
            return sum(key(item) for item in self.items)
        return sum(self.items)

    def avg(self, key= None): 
        if not self.items:
            return None
        return self.sum(key) / self.count()

    def max(self, key= None): 
        if not self.items:
            return None
        return max(self.items, key=key) if key else max(self.items)

    def min(self, key= None): 
        if not self.items:
            return None
        return min(self.items, key=key) if key else min(self.items)
    
    def json(self):
        # import json
        # return json.dumps(self.items)
        return self.items
    

    def __getitem__(self, index):
        return self.items[index]
    
    def __setitem__(self, index, value):
        self.items[index] = value

    def __len__(self):
        return len(self.items)

    def __iter__(self):
        return iter(self.items)

    def __str__(self):
        return self.items.__str__()
    
    def __repr__(self):
        return f"Collection({self.items})"



# Usage:
# collection = Collection([1, 2, 3, 4, 5])
# print(collection)
# print(collection.all())
# print(collection.count())
# print(collection.sum())
# print(collection.avg())
# print(collection.max())
# print(collection.min())
# print(collection.first())
# print(collection.last())
# print(collection.where(2))
# print(collection.sort())
# print(collection.chunk(2))
# print(collection.pluck('name'))
# print(collection.merge([6, 7, 8, 9, 10]))
# print(collection.filter(lambda x: x % 2 == 0))
# print(collection.map(lambda x: x * 2))
# print(collection.reduce(lambda x, y: x + y))
# print(collection.get(2))
# print(collection.set(2, 10))
# print(collection.new([1, 2, 3, 4, 5]))
# print(collection.add(6))
# print(collection.remove(2))
# print(collection.find(2))
# print(collection[2])
# collection[2] = 10
# for item in collection:
#     print(item)
# print(collection)
# print(collection.items)
# print(collection.__repr__())
# print(collection.__str__())
# print(collection.__len__())
# print(collection.__iter__())
# print(collection.__getitem__(2))
# print(collection.__setitem__(2, 10) 