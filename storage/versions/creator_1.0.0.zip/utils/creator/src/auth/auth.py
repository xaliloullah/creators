class Auth:
    pass