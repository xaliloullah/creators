from utils.creator.src.app.creator import Creator

Creator.configure()