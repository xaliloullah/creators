from utils.creator.src.requests.request import Request
from utils.creator.src.core.view import View 
from utils.creator.src.core.hash import Hash 

from app.models.user import User

class LoginController:

    @staticmethod
    def index():
        #
        return

    @staticmethod
    @View.extend("console.home")
    @View.section("title", "LOGIN") 
    @View.section("content")
    def create():
        #
        return View("console.auth.login")

    @staticmethod
    def store(request: Request):
        request.validate({
            # 'email': ["required","email"], #"unique:users"
            'name': ["required", "string"], 
            'password': ["string", "required"]
        })    
        user = User().where(name=request['name']).first()
        if user: 
            if Hash().check(request['password'], user["password"]):
                request.session.set(user["id"])
                request.session.success("connecter avec succees")
                
                return View.back()
            else:
                request.session.error("mot de passe incorrect") 
                return View.back()
        else:
            request.session.error("utilisateur non trouve")
            return View.back() 
    @staticmethod
    def edit(id):
        #
        return

    @staticmethod
    def update(request: Request, id):
        #
        return

    @staticmethod
    def show(id):
        #
        return

    @staticmethod
    def destroy(id):
        #
        return
    