from utils.creator.src.requests.request import Request
from utils.creator.src.core.view import View  
from utils.creator.src.core.hash import Hash 

from app.models.user import User

class RegisterController:

    @staticmethod
    def index():
        #
        return

    @staticmethod
    @View.extend("console.home")
    @View.section("title", "REGISTER") 
    @View.section("content")
    def create():
        #
        return View("console.auth.register")

    @staticmethod
    def store(request: Request):
        request.validate({
            'name': ["required", "string", "min:3", "max:50", "unique:users"], 
            'email': ["required","email", "unique:users"], 
            'password': ["string", "password"]
        })  
        users = User()
        users.create(
            name = request['name'],
            email = request['email'],
            password = Hash().make(request['password'])
        ) 
        
        request.session.success("ajouter avec succees")
        return View.back()

    @staticmethod
    def edit(id):
        #
        return

    @staticmethod
    def update(request: Request, id):
        #
        return

    @staticmethod
    def show(id):
        #
        return

    @staticmethod
    def destroy(id):
        user = User().find(id) 
        user.delete() 
    
        # request.session.success("Supprimer avec succees")
        return View.back() 
    