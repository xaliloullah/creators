from utils.creator.src.requests.request import Request
from utils.creator.src.core.view import View 

from app.models.test import Test

class TestController:
     
    @staticmethod
    @View.extend("console.home")
    @View.section("title", "TEST - INDEX") 
    @View.section("content")
    def index(): 
        tests = Test().all()
        return View('console.pages.test.index', View.compact(tests=tests))

    @staticmethod
    @View.extend("console.home")
    @View.section("title", "TEST - CREATE") 
    @View.section("content")
    def create(): 
        return View('console.pages.test.create')

    @staticmethod
    def store(request: Request):  
        request.validate({
            'name': ["required", "string", "min:3", "max:10"], 
            'etat': ["required","integer"], 
            'details': ["string"]
        })  
        test = Test()
        test.create(
            name = request['name'],
            etat = request['etat'],
            details = request['details']
        ) 
        
        request.session.success("ajouter avec succees")
        return View.back() 
    
    @staticmethod
    @View.extend("console.home")
    @View.section("title", "TEST - EDIT") 
    @View.section("content")
    def edit(id):
        test = Test().find(id)
        return View('console.pages.test.edit', View.compact(test=test))

    @staticmethod 
    def update(request: Request, id):
        test = Test().find(id)
        test.update(
            name = request['name'],
            etat = request['etat'],
            details = request['details']
        ) 
        request.session.success("modifier avec succees")
        return View.back() 

    @staticmethod
    @View.extend("console.home")
    @View.section("title", "TEST - SHOW") 
    @View.section("content")
    def show(id):
        test = Test().find(id) 
        return View('console.pages.test.view', View.compact(test=test))


    @staticmethod
    def destroy(id):
        test = Test().find(id) 
        test.delete() 
    
        # request.session.success("Supprimer avec succees")
        return View.back() 
    