from creators.src.controllers.controller import *
from app.models.user import User

class UserController:
    @staticmethod
    def index():
        users = User().all()
        test='salut p'  
        return view('pages/users/index', compact(users=users, test=test))

    @staticmethod
    def create(): 
        return view('pages/users/create')

    @staticmethod
    def store(request: Request):
        request.validate({
            'name': ["required", "string", "min:3", "max:50"],
            'email': ["required","email", "unique:Users"],
            'password': ["required","string"],
            'age': ["required","integer"]
        })
        user = User()
        user.create(
            name=request['name'],
            email=request['email'],
            password=request['password'],
            age=request['age']
        )
        return back()

    @staticmethod
    def update(request: Request, id):
        request.validate({
            'name': ["required", "string", "min:3", "max:50"],
            'email': ["required", "email"],
            'password': ["nullable", "string"],
            'age': ["required", "integer"]
        })

        user = User().find(id)
        user.update(
            name=request['name'],
            email=request['email'],
            password=request['password'],
            age=request['age']
        )
        return back()


    @staticmethod
    def show(id):
        user = User().find(id) 
        return view('pages/users/show', compact(user=user))


    @staticmethod
    def destroy(id):
        user = User().find(id) 
        user.delete()
        return back()


