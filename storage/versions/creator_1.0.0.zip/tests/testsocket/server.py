# server.py
import socket
 
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Lier le socket à une adresse IP et un port
server_socket.bind(('127.0.0.1', 65432))  # Localhost et port 65432

# Mettre le socket en mode écoute
server_socket.listen(1)  # Le nombre de connexions simultanées autorisées

print("Serveur en attente de connexion...")

# Accepter une connexion
conn, addr = server_socket.accept()
print(f"Connexion établie avec {addr}")

# Recevoir des données
data = conn.recv(1024).decode('utf-8')  # Taille maximale des données reçues en octets
print(f"Reçu : {data}")

# Envoyer une réponse
conn.sendall("Bonjour depuis le serveur !".encode('utf-8'))

# Fermer la connexion
conn.close()
server_socket.close()
