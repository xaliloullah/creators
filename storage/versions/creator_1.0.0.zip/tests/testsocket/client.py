# client.py
import socket
 
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Se connecter au serveur
client_socket.connect(('0.0.0.0', 8000)) 

# Envoyer un message
client_socket.sendall("Bonjour serveur !".encode('utf-8'))

# Recevoir une réponse
data = client_socket.recv(1024).decode('utf-8')
print(f"Réponse du serveur : {data}")

# Fermer la connexion
client_socket.close()
