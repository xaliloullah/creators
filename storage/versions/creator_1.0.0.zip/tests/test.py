import keyboard

def input_password(prompt="Entrez votre mot de passe : "):
    print(prompt, end='', flush=True)
    password = ''
    while True:
        event = keyboard.read_event(suppress=True)
        if event.event_type == 'down':  # Ne traite que les événements de touche "appuyée"
            char = event.name
            if char == 'enter':
                print()  # Nouvelle ligne
                break
            elif char == 'backspace':
                if len(password) > 0:
                    password = password[:-1]
                    print('\b \b', end='', flush=True)
            elif len(char) == 1:  # Vérifie que c'est un caractère valide
                password += char
                print('*', end='', flush=True)
    return password

password = input_password()
print("Mot de passe enregistré !")

