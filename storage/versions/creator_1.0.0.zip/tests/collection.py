from typing import Callable, Iterable, List, Any, Optional, Union, Dict, Tuple


class Collection:
    def __init__(self, items: Optional[Iterable[Any]] = None):
        self.items = list(items) if items else []

    def all(self) -> List[Any]:
        """Retourne tous les éléments sous forme de liste."""
        return self.items

    def map(self, func: Callable[[Any], Any]) -> 'Collection':
        """Applique une fonction à chaque élément."""
        return Collection(map(func, self.items))

    def filter(self, func: Optional[Callable[[Any], bool]] = None) -> 'Collection':
        """Filtre les éléments en fonction d'une condition."""
        return Collection(filter(func, self.items))

    def reduce(self, func: Callable[[Any, Any], Any], initial: Optional[Any] = None) -> Any:
        """Réduit les éléments en un seul résultat."""
        from functools import reduce
        return reduce(func, self.items, initial)

    def add(self, item: Any) -> 'Collection':
        """Ajoute un élément à la collection."""
        self.items.append(item)
        return self

    def merge(self, other: Iterable[Any]) -> 'Collection':
        """Fusionne une autre collection ou liste avec celle-ci."""
        self.items.extend(other)
        return self

    def first(self, func: Optional[Callable[[Any], bool]] = None) -> Optional[Any]:
        """Retourne le premier élément qui satisfait une condition, ou le premier élément."""
        if func:
            for item in self.items:
                if func(item):
                    return item
        return self.items[0] if self.items else None

    def last(self, func: Optional[Callable[[Any], bool]] = None) -> Optional[Any]:
        """Retourne le dernier élément qui satisfait une condition, ou le dernier élément."""
        if func:
            for item in reversed(self.items):
                if func(item):
                    return item
        return self.items[-1] if self.items else None

    def sort(self, key: Optional[Callable[[Any], Any]] = None, reverse: bool = False) -> 'Collection':
        """Trie les éléments."""
        self.items.sort(key=key, reverse=reverse)
        return self

    def reverse(self) -> 'Collection':
        """Inverse l'ordre des éléments."""
        self.items.reverse()
        return self

    def chunk(self, size: int) -> 'Collection':
        """Divise la collection en morceaux de taille donnée."""
        if size <= 0:
            raise ValueError("La taille doit être supérieure à 0.")
        chunks = [self.items[i:i + size] for i in range(0, len(self.items), size)]
        return Collection(chunks)

    def flatten(self) -> 'Collection':
        """Aplatie une collection multi-niveaux en une collection simple."""
        def _flatten(items):
            for item in items:
                if isinstance(item, (list, tuple, set)):
                    yield from _flatten(item)
                else:
                    yield item
        return Collection(_flatten(self.items))

    def unique(self, key: Optional[Callable[[Any], Any]] = None) -> 'Collection':
        """Retourne une collection avec des valeurs uniques."""
        seen = set()
        result = []
        for item in self.items:
            val = key(item) if key else item
            if val not in seen:
                seen.add(val)
                result.append(item)
        return Collection(result)

    def contains(self, value: Any) -> bool:
        """Vérifie si une valeur est dans la collection."""
        if callable(value):
            return any(value(item) for item in self.items)
        return value in self.items

    def count(self) -> int:
        """Retourne le nombre d'éléments dans la collection."""
        return len(self.items)

    def sum(self, key: Optional[Callable[[Any], Union[int, float]]] = None) -> Union[int, float]:
        """Retourne la somme des éléments."""
        if key:
            return sum(key(item) for item in self.items)
        return sum(self.items)

    def avg(self, key: Optional[Callable[[Any], Union[int, float]]] = None) -> Optional[float]:
        """Retourne la moyenne des éléments."""
        if not self.items:
            return None
        return self.sum(key) / self.count()

    def max(self, key: Optional[Callable[[Any], Any]] = None) -> Optional[Any]:
        """Retourne le maximum des éléments."""
        if not self.items:
            return None
        return max(self.items, key=key) if key else max(self.items)

    def min(self, key: Optional[Callable[[Any], Any]] = None) -> Optional[Any]:
        """Retourne le minimum des éléments."""
        if not self.items:
            return None
        return min(self.items, key=key) if key else min(self.items)

    def to_dict(self, key_func: Callable[[Any], Any], value_func: Callable[[Any], Any]) -> Dict[Any, Any]:
        """Transforme la collection en dictionnaire."""
        return {key_func(item): value_func(item) for item in self.items}

    def __len__(self) -> int:
        """Permet l'utilisation de len() sur la collection."""
        return self.count()

    def __iter__(self):
        """Rend la collection itérable."""
        return iter(self.items)

    def __repr__(self) -> str:
        """Représentation lisible de la collection."""
        return f"Collection({self.items})"
    
    
if __name__ == "__main__":
    col = Collection([1, 2, 3, 4, 5])
    print(col.all())  # [1, 2, 3, 4, 5]
    print(col.map(lambda x: x * 2))  # Collection([2, 4, 6, 8, 10])
    print(col.filter(lambda x: x > 3))  # Collection([4, 5])
    print(col.reduce(lambda x, y: x + y, 0))  # 15
    print(col.first())  # 1
    print(col.last())  # 5
    print(col.chunk(2))  # Collection([[1, 2], [3, 4], [5]])
    print(col.flatten())  # Collection([1, 2, 3, 4, 5])
    print(col.unique())  # Collection([1, 2, 3, 4, 5])
    print(col.sum())  # 15
    print(col.avg())  # 3.0
    print(col.max())  # 5
    print(col.min())  # 1
