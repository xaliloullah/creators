layouts = {}
# 
def section(key, value=None):   
    def decorator(function):
        def wrapper(*args, **kwargs): 
            if value:
                layouts[key] = value 
                return function(*args, **kwargs)  
            else:
                layouts[key] = {'action': function, 'args': args, 'kwargs': kwargs}  
                return
        return wrapper
    return decorator

def extend(path):
    def decorator(function):
        def wrapper(*args, **kwargs): 
            function(*args, **kwargs)
            if path == "home":
                return home()
            elif path == "home2":
                return home2() 
            return 
        return wrapper
    return decorator

def generate(layout): 
    result = layouts.get(layout)  
    if isinstance(result, dict):
        return result['action'](*result['args'], **result['kwargs']) 
    elif result:   
        return result
    else:
        return ""

def home2():
    print("Affichage du header, menu, etc.")
    print("--- Début de la vue home 2---\n")  
    generate("content")
    print("\nAffichage du footer 2.")
    print("--- Fin de la vue home 2---") 

@extend("home")
@section("title", "Accueil")
@section("title2", "Tets")
@section("content")
def main():
    print(f"Accueil.")  
    print(f"Service.")  
    print(f"Contenu de la vue principale.")  

def home():
    print(f"--- HOME - {generate("title")}  / {generate("title2")} ---\n")  
    
    print("Affichage du header, menu, etc.")
    print("--- Début de la vue home ---\n")  
    generate("content")
    print("\nAffichage du footer.")
    print("--- Fin de la vue home ---") 

main()
