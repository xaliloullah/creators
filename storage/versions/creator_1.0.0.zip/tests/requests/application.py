from route import Route
from request import Http 
from di import DependencyInjector
 
class Application:
    def configure(self):
        return self
    
    def create(self):
        return self 
    
    def with_middleware(self):
        pass
    
    def with_routing(self):
        pass
    
    def with_exceptions(self):
        pass
     
    @staticmethod
    def handle(request: Http):   
        handler = Route.dispatch(request.method, request.url)  
        
        di = DependencyInjector()
        di.register(Http, request) 
        if handler:
            try: 
                if handler["params"]:
                    response = di.resolve(handler["action"], **handler["params"])
                else:
                    response = di.resolve(handler["action"])
                 
                return response
            except Exception as e:
                print(f"Error while handling request: {e}")
                raise
        else:
            raise ValueError(f"No handler found for URL '{request.url}' and method '{request.method}'.")
        
    @staticmethod
    def terminate(request, response):  
        pass 