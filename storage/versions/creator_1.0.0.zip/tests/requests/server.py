from wsgiref.simple_server import make_server
import threading
import io
import sys

class Server:  
    port = 8000
    host = "127.0.0.1"
    stop_event = threading.Event()

    @classmethod
    def application(cls, environ, start_response):
        path = "./public/main.py"
 
        old_stdout = sys.stdout
        sys.stdout = io.StringIO() 
        globals()["__SERVER__"] = environ  
        with open(path) as f:
            exec(f.read(), globals())

        # Capture the output from main.py
        response_body = sys.stdout.getvalue()

        # Restore the original stdout
        sys.stdout = old_stdout

        # Send the HTTP response
        status = '200 OK'
        response_headers = [('Content-type', 'text/plain')]
        start_response(status, response_headers)

        # Return the captured output as the response
        return [response_body.encode('utf-8')]
    
  
    @classmethod
    def run(cls):
        # import os
        # os.chdir("/public/index.html")
        httpd = make_server(cls.host, cls.port, cls.application)
        try:  
            while not cls.stop_event.is_set():
                httpd.handle_request() 
        except KeyboardInterrupt:
            pass
        finally:
            httpd.server_close()  

    @classmethod
    def get_port(cls):
        return cls.port
    
    @classmethod
    def set_port(cls, port):
        cls.port = port
        
    @classmethod
    def get_address(cls):
        return cls.address
    
    @classmethod
    def set_address(cls, address):
        cls.address = address
        
    @classmethod
    def start(cls):
        server_thread = threading.Thread(target=cls.run, daemon=True)
        server_thread.start() 
    
    @classmethod
    def stop(cls): 
        cls.stop_event.set() 
