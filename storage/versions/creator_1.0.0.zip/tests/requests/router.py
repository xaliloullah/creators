import re
from urllib.parse import urlparse, parse_qs
class Router:
    def __init__(self):
        self.routes = {}
        self.absolute = "http://localhost:8000"

    def create(self, method, uri, action, name=None): 
        self._route = {
            'method': method,
            'uri': uri,
            'action': action,
            'name': name
        } 
        return self
         
    def add(self):
        if hasattr(self, '_route'):
            route = self._route
            method = route["method"]
            if method not in self.routes:
                self.routes[method] = []
                
            self.routes[route["method"]].append({'uri': route['uri'], 'action': route['action'], 'name': route['name']})
            
            del self._route   
        return self 
        
    def get(self, uri, action, name=None): 
        self.create("GET", uri, action, name).add()

    def post(self, uri, action, name=None):
        self.create("POST", uri, action, name).add()

    def put(self, uri, action, name=None):
        self.create("PUT", uri, action, name).add()

    def delete(self, uri, action, name=None):
        self.create("DELETE", uri, action, name).add()

    def patch(self, uri, action, name=None):
        self.create("PATCH", uri, action,name).add()

    def any(self, uri, action, name=None):
        self.create("ANY", uri, action, name).add()

    def group(self, attributes, action: callable): 
        attributes
        # if 'prefix' in attributes:
        #     self._prefix = attributes['prefix'] 
        action()   
        # self._prefix = ""
        
    def resource(self, name, controller):
        self.get(f'/{name}', controller.index, f'{name}.index')      
        self.get(f'/{name}/create', controller.create, f'{name}.create')  
        self.post(f'/{name}/store', controller.store, f'{name}.store')       
        self.get(f'/{name}/{{id}}', controller.show, f'{name}.show')
        self.get(f'/{name}/{{id}}/edit', controller.edit, f'{name}.edit')
        self.put(f'/{name}/{{id}}/update', controller.update, f'{name}.update')
        self.delete(f'/{name}/{{id}}/destroy', controller.destroy, f'{name}.destroy')
        
    def controller(self, controller):
        pass           
    
    def prefix(self, prefix):
        pass
        
    def list(self):
        return self.routes

    def show(self): 
        return self.routes
     
    def route_name(self, name, method):
        try:
            if method in self.routes: 
                for route in self.routes[method]:
                    if route['name'] == name:
                        return route
        except Exception as e: 
            raise Exception(e) 
        
    def route_uri(self, url, method):
        try:
            if method in self.routes: 
                for route in self.routes[method]:
                    if self.resolve(url, f"{self.absolute}{route['uri']}") == url:
                        return route
        except Exception as e: 
            raise Exception(e)
        
    def dispatch(self, method: str, uri: str): 
        return self.resolve(method.upper(), uri) 
   
    def resolve(self, method, uri: str):
        try:  
            url = urlparse(uri)
            if method in self.routes: 
                for route in self.routes[method]: 
                    pattern = re.sub(r'\{(\w+)\}', r'(?P<\1>[^/]+)', f"{route['uri']}")
                    pattern = f'^{pattern}$'
                     
                    match = re.match(pattern, url.path)
                    if match:   
                        params = match.groupdict() 
                        return {
                            'method': method,
                            'params': params,
                            'query': {key: value[0] for key, value in parse_qs(url.query).items()},   
                            'action': route['action'],
                            'scheme': url.scheme,
                            'netloc': url.netloc,
                            'path': url.path,
                            'fragment': url.fragment,
                            'port': url.port,
                            'hostname': url.hostname, 
                        } 
            return None
        except Exception as e: 
            raise Exception(e) 

    def route(self, method: str, arg, **params):  
        try:
            absolute = params.get("absolute", True)

            route = self.route_name(arg, method.upper())
            if route:
                uri: str = route['uri']
                if params:
                    for param, value in params.items():
                        try:
                            uri = uri.replace(f"{{{param}}}", str(value))
                        except Exception as e:
                            print(f"Error while replacing param '{param}': {e}")
                if absolute:
                    uri = f"{self.absolute}{uri}" 
                return uri
            else:
                raise Exception(f"Route '{arg}' not found.")
        except Exception as e:
            raise Exception(e) 
    
    def url(self, url):
        pass