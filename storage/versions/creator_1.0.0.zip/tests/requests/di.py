class DependencyInjector:
    def __init__(self):
        self._dependencies = {}

    def register(self, cls, instance=None):
        """
        Enregistre une dépendance dans le conteneur.
        Si une instance est fournie, l'instance est enregistrée.
        Si aucune instance n'est fournie, la classe est enregistrée et une nouvelle instance sera créée lors de la résolution.
        """
        if instance is None:
            self._dependencies[cls] = cls
        else:
            self._dependencies[cls] = instance

    def inject(self, annotation):
        """
        Résout une dépendance en créant une nouvelle instance de la classe enregistrée ou retourne une instance existante.
        """
        if annotation in self._dependencies: 
            dependency = self._dependencies[annotation]
            return dependency
        return None

    def resolve(self, func, *args, **kwargs):
        from inspect import signature
        """
        Injecte automatiquement les dépendances manquantes dans la fonction `func`.
        Résout les dépendances à partir des annotations de type des paramètres.
        """
        sig = signature(func)
        for param_name, param in sig.parameters.items():
            if param.annotation != param.empty and param_name not in kwargs:
                dependency = self.inject(param.annotation)
                if dependency is not None:
                    kwargs[param_name] = dependency
                else:
                    raise Exception(f"Impossible de résoudre la dépendance pour le paramètre: {param_name}")
        return func(*args, **kwargs)