from application import Application
from route import Route
from request import Http
from server import Server
 
# Exemple d'utilisation :
if __name__ == "__main__":
    # Import de la classe Route 

    # Exemple de gestionnaires (handlers)
    def index():
        print("--- index ---")
        return

    def store(requests: Http, id, test):
        print(f"--- store --- {id}")
        print(requests)
        return 
    
    class Controller:
        def index(): 
            return print("salut toi")
        def create():
            pass
        def store(req: Http):
            print(req.data)
            return
        def show():
            pass
        def edit():
            pass
        def update(id, name):
            print("updating data...")
            return
        def destroy():
            pass 
        
    # Ajouter des routes
    Route.post("/store", Controller.store, "test.store")
    
    Route.put("/update/{id}/{name}", Controller.update, "update")
    
    Route.get("/home", Controller.index, "index") 
    Route.resource("khalil", Controller)
  
 
    # print(Route.dispatch("PUT", "/update/123/khalil", id=123, name="khalil")) 
    # Route.create("GET","http://localhost:8000/index", index)
    # Route.create("POST", "http://localhost:8000/store", store)

    
    Server.start()
    app = Application()
    
    app.configure().create()
    
    request = Http() 
    import requests
    response = requests.get("http://localhost:8000/home")
    # request.put(Route.route("put", "update", **{"id":"1","name":"khalil"}))
    # Route.route("put", "update", **{"id":"1","name":"khalil"})
    # request.put(Route.route("put", "update", **{"id":"1","name":"khalil"}))
    
    # request.put("http://localhost:8000/update/1/khalil")

    app.handle(request)