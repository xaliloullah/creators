from router import Router
class Route:
    _router = Router()

    @staticmethod
    def get(uri, action, name=None):
        Route._router.get(uri, action, name)

    @staticmethod
    def post(uri, action, name=None):
        Route._router.post(uri, action, name)

    @staticmethod
    def put(uri, action, name=None):
        Route._router.put(uri, action, name)

    @staticmethod
    def delete(uri, action, name=None):
        Route._router.delete(uri, action, name)

    @staticmethod
    def patch(uri, action, name=None):
        Route._router.patch(uri, action, name)

    @staticmethod
    def any(uri, action, name=None):
        Route._router.any(uri, action, name)
        
    @staticmethod
    def resource(uri, action):
        Route._router.resource(uri, action)

    @staticmethod
    def group(attributes, action):
        Route._router.group(attributes, action)

    @staticmethod
    def controller():
        return Route._router.controller()
    
    @staticmethod
    def show():
        return Route._router.show()
        
    @staticmethod
    def list():
        return Route._router.list()
     
    @staticmethod
    def route(method, route_name, **params):
        return Route._router.route(method, route_name, **params)
    
    @staticmethod
    def dispatch(method, uri):
        return Route._router.dispatch(method, uri)


