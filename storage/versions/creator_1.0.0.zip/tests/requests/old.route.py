import re

class Route:
    def __init__(self):
        self.routes = {}

    def add(self, path, method, handler):
        if path not in self.routes:
            self.routes[path] = {}
        self.routes[path][method] = handler

    def dispatch(self, path, method): 
        for route in self.routes: 
            pattern = self._path_to_regex(route)
            match = re.match(pattern, path)
            if match:
                params = match.groupdict() 
                return self.routes[route][method], params
        return None, None 

    def _path_to_regex(self, path): 
        pattern = re.sub(r'\{(\w+)\}', r'(?P<\1>[^/]+)', path)  
        pattern = f"^{pattern}$"  
        return pattern
    
    def route(self, path, parameters=None, absolute=True):
        if absolute:
            return f"http://localhost:8000{path}"
        return path
  
  
routes = Route()  

def home(id):
    print("--- page home your welcome ---") 

def about(request, params):
    pass
    

def contact(id, name):
    print(f"contact: id : {id} name : {name}")
    
    return 

def post(request, params):
    pass 

def put(request, params):
    pass 

def delete(request, params):
    pass 

def patch(request, params):
    pass 

def head(request, params):
    pass 

def options(request, params):
    pass 
    
routes.add('http://localhost:8000/home/{id}', 'GET', home)
routes.add('/about', 'GET', about)
routes.add('/contact/{id}/{name}', 'GET', contact)
routes.add('/post-test/{id}', 'POST', post)
routes.add('/put-test{id}', 'PUT', put)
routes.add('/delete/{id}', 'DELETE', delete)
routes.add('/patch-test/{name}', 'PATCH', patch)
routes.add('/head', 'HEAD', head)
routes.add('/options', 'OPTIONS', options)