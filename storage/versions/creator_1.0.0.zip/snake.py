import sys
import random
from PyQt5.QtCore import Qt, QTimer, QPoint
from PyQt5.QtGui import QColor, QPainter 
from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5.QtGui import QKeyEvent


class SnakeGame(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Jeu Snake")
        self.setGeometry(100, 100, 400, 400)
        self.setStyleSheet("background-color: black;")
        
        self.snake = [QPoint(100, 100), QPoint(90, 100), QPoint(80, 100)]
        self.food = QPoint(0, 0)
        self.direction = Qt.Key_Right
        self.is_game_over = False
        self.score = 0
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_game)
        self.timer.start(100)  # Mise à jour toutes les 100 ms

        self.spawn_food()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        if self.is_game_over:
            self.display_game_over(painter)
        else:
            self.draw_snake(painter)
            self.draw_food(painter)
            self.display_score(painter)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key_Up and self.direction != Qt.Key_Down:
            self.direction = Qt.Key_Up
        elif event.key() == Qt.Key_Down and self.direction != Qt.Key_Up:
            self.direction = Qt.Key_Down
        elif event.key() == Qt.Key_Left and self.direction != Qt.Key_Right:
            self.direction = Qt.Key_Left
        elif event.key() == Qt.Key_Right and self.direction != Qt.Key_Left:
            self.direction = Qt.Key_Right

    def update_game(self):
        if self.is_game_over:
            return

        head = self.snake[0]
        if self.direction == Qt.Key_Up:
            head = QPoint(head.x(), head.y() - 10)
        elif self.direction == Qt.Key_Down:
            head = QPoint(head.x(), head.y() + 10)
        elif self.direction == Qt.Key_Left:
            head = QPoint(head.x() - 10, head.y())
        elif self.direction == Qt.Key_Right:
            head = QPoint(head.x() + 10, head.y())

        # Si le serpent touche les bords de la fenêtre
        if not self.is_valid_move(head):
            self.is_game_over = True
            self.update()
            return

        # Déplacer le serpent
        self.snake.insert(0, head)

        # Si le serpent mange la nourriture
        if head == self.food:
            self.score += 1
            self.spawn_food()
        else:
            self.snake.pop()

        self.update()

    def is_valid_move(self, point):
        if point.x() < 0 or point.x() >= self.width() or point.y() < 0 or point.y() >= self.height():
            return False
        return point not in self.snake

    def spawn_food(self):
        # Créer une position de nourriture aléatoire
        self.food = QPoint(random.randrange(0, self.width(), 10), random.randrange(0, self.height(), 10))
        while self.food in self.snake:
            self.food = QPoint(random.randrange(0, self.width(), 10), random.randrange(0, self.height(), 10))

    def draw_snake(self, painter):
        painter.setBrush(QColor(0, 255, 0))
        for segment in self.snake:
            painter.drawRect(segment.x(), segment.y(), 10, 10)

    def draw_food(self, painter):
        painter.setBrush(QColor(255, 0, 0))
        painter.drawRect(self.food.x(), self.food.y(), 10, 10)

    def display_score(self, painter):
        painter.setPen(QColor(255, 255, 255))
        painter.drawText(10, 20, f"Score: {self.score}")

    def display_game_over(self, painter):
        painter.setPen(QColor(255, 0, 0))
        painter.setFont(painter.font().bold())
        painter.drawText(self.width() // 2 - 50, self.height() // 2, "Game Over")
        painter.drawText(self.width() // 2 - 50, self.height() // 2 + 20, f"Score final: {self.score}")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    game = SnakeGame()
    game.show()
    sys.exit(app.exec_())
