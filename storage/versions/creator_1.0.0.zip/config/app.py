from utils.creator.src.environment.env import env

app = {
    'name': env('APP_NAME', 'creators'),
    'url': env("APP_URL",'http://localhost'), 
    'lang': env("APP_LOCALE",'en'),
    'mode': env("APP_MODE",'app')
}