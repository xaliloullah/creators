from pydub import AudioSegment
from pydub.playback import play

# 1. Charger un fichier audio
def load_audio(file_path):
    return AudioSegment.from_file(file_path)

# 2. Changer le volume de l'audio
def change_volume(audio, dB):
    return audio + dB  # Ajoute ou diminue le volume en dB

# 3. Couper une section spécifique de l'audio
def cut_audio(audio, start_time_ms, end_time_ms):
    return audio[start_time_ms:end_time_ms]

# 4. Appliquer un effet de fondu en entrée et en sortie
def fade_in_out(audio, fade_in_ms, fade_out_ms):
    return audio.fade_in(fade_in_ms).fade_out(fade_out_ms)

# 5. Appliquer un effet de reverse (inversion)
def reverse_audio(audio):
    return audio.reverse()

# 6. Exporter le fichier audio dans un autre format
def export_audio(audio, output_path, format_type="mp3"):
    audio.export(output_path, format=format_type)

# 7. Mixer plusieurs pistes audio
def mix_audio(audio1, audio2):
    return audio1.overlay(audio2)

# 8. Appliquer un filtre passe-bas (Low pass filter)
def low_pass_filter(audio, cutoff_freq):
    return audio.low_pass_filter(cutoff_freq)

# 9. Appliquer un filtre passe-haut (High pass filter)
def high_pass_filter(audio, cutoff_freq):
    return audio.high_pass_filter(cutoff_freq)

# 10. Ajouter une pause (silence) à l'audio
def add_silence(audio, duration_ms):
    silence = AudioSegment.silent(duration=duration_ms)
    return audio + silence

# 11. Jouer un fichier audio
def play_audio(audio):
    play(audio)

# 12. Découper l'audio en segments (ex : toutes les 10 secondes)
def split_audio(audio, segment_duration_ms):
    segments = []
    for start_ms in range(0, len(audio), segment_duration_ms):
        end_ms = start_ms + segment_duration_ms
        segments.append(audio[start_ms:end_ms])
    return segments

# 13. Calculer la durée de l'audio
def get_audio_duration(audio):
    return len(audio) / 1000  # Durée en secondes

def change_pitch(audio, semitones):
    return audio._spawn(audio.raw_data, overrides={"frame_rate": int(audio.frame_rate * (2 ** (semitones / 12.0)))})


def concatenate_audio(files):
    audios = [AudioSegment.from_file(file) for file in files]
    return sum(audios)  # Additionne les segments audio les uns après les autres

def split_on_silence(audio, min_silence_len=1000, silence_thresh=-40):
    return audio.split_to_mono()[0].split_on_silence(min_silence_len=min_silence_len, silence_thresh=silence_thresh)

def separate_channels(audio):
    channels = audio.split_to_mono()  # Retourne une liste de deux AudioSegment : [gauche, droit]
    return channels

def split_audio_by_seconds(audio, segment_duration_seconds):
    segment_duration_ms = segment_duration_seconds * 1000  # Convertir en millisecondes
    return split_audio(audio, segment_duration_ms)

def extract_sample(audio, start_ms, end_ms):
    return audio[start_ms:end_ms]

def export_audio_with_options(audio, output_path, format_type="mp3", bitrate="192k", frame_rate=44100):
    audio.export(output_path, format=format_type, bitrate=bitrate, parameters=["-ar", str(frame_rate)])

def get_audio_metadata(audio):
    return {
        "channels": audio.channels,
        "sample_width": audio.sample_width,
        "frame_rate": audio.frame_rate,
        "frame_count": audio.frame_count(),
        "duration_ms": len(audio)
    }

def transpose_audio(audio, semitones):
    return audio._spawn(audio.raw_data, overrides={"frame_rate": int(audio.frame_rate * (2 ** (semitones / 12.0)))})

def generate_sine_wave(frequency=440, duration_ms=1000, amplitude=0.5):
    sample_rate = 44100
    sine_wave = AudioSegment.sine(frequency=frequency, duration=duration_ms, volume=amplitude)
    return sine_wave


# Exemple d'utilisation
def main():
    # Charger un fichier audio
    audio = load_audio("example.mp3")

    # Appliquer quelques transformations
    audio = change_volume(audio, 5)  # Augmenter le volume de 5 dB
    audio = fade_in_out(audio, 3000, 3000)  # Fondu en entrée et sortie de 3 secondes
    audio_cut = cut_audio(audio, 30000, 60000)  # Découper entre 30s et 60s
    audio_reversed = reverse_audio(audio_cut)  # Inverser l'audio
    audio_filtered = low_pass_filter(audio_reversed, 1500)  # Appliquer un filtre passe-bas à 1500 Hz
    audio_with_silence = add_silence(audio_filtered, 5000)  # Ajouter 5 secondes de silence

    # Mixer deux audios
    audio2 = load_audio("example2.mp3")
    mixed_audio = mix_audio(audio_with_silence, audio2)

    # Exporter le résultat
    export_audio(mixed_audio, "output_audio.mp3", format_type="mp3")

    # Afficher la durée de l'audio final
    print(f"Durée de l'audio final : {get_audio_duration(mixed_audio)} secondes")

    # Jouer l'audio
    play_audio(mixed_audio)

# Lancer le script
if __name__ == "__main__":
    main()
 
# 1. Charger un fichier audio
audio = AudioSegment.from_file("example.mp3")

# 2. Changer le volume
audio = audio + 5

# 3. Appliquer un fondu en entrée et en sortie
audio = audio.fade_in(2000).fade_out(2000)

# 4. Séparer les canaux stéréo
channels = audio.split_to_mono()
left_channel = channels[0]
right_channel = channels[1]

# 5. Modifier la vitesse (changer le tempo)
audio_fast = audio.speedup(playback_speed=1.5)

# 6. Ajouter une tonalité sinusoidale de 440 Hz (A4)
sine_wave = AudioSegment.sine(frequency=440, duration=1000, volume=0.5)

# 7. Concatenation des audio (ajouter un son à la fin)
final_audio = audio + sine_wave

# 8. Exporter le fichier audio final
final_audio.export("final_output.mp3", format="mp3")

# 9. Lire l'audio final
play(final_audio)
