class Cookies:
    pass

    def Cookies(self,name,time):
        pass