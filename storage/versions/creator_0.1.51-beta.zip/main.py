# ---------------------------------------------------------
#  _________                        __              
#  \_   ___ \_______   ____ _____ _/  |_  ___________
#  /    \  \/\_  __ \_/ __ \\__  \\   __\/  _ \_  __ \
#  \     \____|  | \/\  ___/ / __ \|  | (  <_> )  | \/
#   \______  /|__|    \___  >____  /__|  \____/|__|  
#          \/             \/     \/                       
#
# --------------------------------------------------------- 
# Name : creator
# Vesrion : 1.0.1
# Auteur : Khalil
# Date de création : 22/09/2024
# Description :
# Copyright (c) 2025 Creator
# Tous droits réservés.
# --------------------------------------------------------- 


from utils.creator.src.app import Creator

if __name__ == '__main__':
    
    Creator.configure(main="main")
    while True:
        Creator.start()
         
    