from main import Creator  
from app.models.user import User
class Auth:
    def __init__(self): 
        self.user:User = None

    def authenticate(self, user): 
        if user and isinstance(user, User):  
            if Creator.hash.check(Creator.request['password'], user["password"]):
                Creator.request.session.set("user_id", user["id"])
                Creator.request.session.update()
                self.user = user

    def check(self):
        return bool()