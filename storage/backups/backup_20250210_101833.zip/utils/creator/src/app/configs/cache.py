class Cache :
    from utils.creator.src.core import Storage, Path, File, Task
    path = Path.cache

    @classmethod
    def config(cls, source='config'):
        cache = cls.Storage(cls.path, absolute=False, format='py') 
        configs = cls.File.list_dir(source, endswith='.py')  
        cache.create(cls.Task.build_import(source, *configs)) 