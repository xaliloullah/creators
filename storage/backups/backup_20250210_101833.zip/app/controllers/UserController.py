from utils.creator.src.requests.request import Request
from utils.creator.src.core.view import View 
from app.models.user import User

class UserController:

    @staticmethod
    def index():
        #
        return

    @staticmethod
    def create():
        #
        return

    @staticmethod
    def store(request: Request):
        #
        return

    @staticmethod
    def edit(id):
        #
        return

    @staticmethod
    def update(request: Request, id):
        #
        return

    @staticmethod
    def show(id):
        #
        return

    @staticmethod
    def destroy(id):
        #
        return
    