from utils.creator.src.core import Storage

class User(Storage):
    def __init__(self):
        self.path = 'data/users'
        super().__init__(path = self.path, format="json")
        # 
