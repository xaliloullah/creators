from utils.creator.src.environment.env import env

app = {
    'name': env('APP_NAME', 'creator'),
    'url': env("APP_URL",'http://localhost'), 
    'lang': env("APP_LANG",'en'),
    'key': env("APP_KEY", None),
    'debug': env("APP_DEBUG", False)
}