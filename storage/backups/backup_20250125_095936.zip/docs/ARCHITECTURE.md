├── .env
├── app
│   ├── controllers
│   │   ├── auth
│   │   │   ├── LoginController.py
│   │   │   └── RegisterController.py
│   │   ├── TestController.py
│   │   └── UserController.py
│   └── models
│       ├── categorie.py
│       ├── file.py
│       ├── produit.py
│       ├── test.py
│       └── user.py
├── config
│   ├── app.py
│   ├── database.py
│   ├── log.py
│   └── session.py
├── creator
├── database
│   ├── creator.db
│   └── migrations
│       ├── 2024_10_07_create_categories_table.py
│       ├── 2024_10_07_create_produits_table.py
│       ├── 2024_12_10_create_tests_table.py
│       └── 2024_12_23_create_users_table.py
├── docs
│   └── ARCHITECTURE.md
├── lang
│   └── en
│       ├── alert.json
│       ├── custom.json
│       ├── password.json
│       ├── settings.json
│       └── validation.json
├── main.py
├── public
│   ├── .htaccess
│   ├── app.py
│   ├── assets
│   │   ├── css
│   │   │   └── creator.css
│   │   └── images
│   │       ├── logo
│   │       │   ├── favicon.ico
│   │       │   └── logo.png
│   │       └── test.png
│   ├── index-.html
│   └── index.html
├── requirements.json
├── resources
│   └── views
│       ├── app.cre
│       ├── auth
│       │   ├── login.cre
│       │   └── register.cre
│       ├── components
│       │   └── alert.cre
│       ├── dashboard.cre
│       ├── includes
│       │   ├── debug.cre
│       │   ├── footer.cre
│       │   └── header.cre
│       └── pages
│           ├── main.cre
│           └── test
│               ├── create.cre
│               ├── edit.cre
│               ├── index.cre
│               └── view.cre
├── routes
│   ├── app.py
│   ├── auth.py
│   └── route.py
└── storage
    ├── backups
    │   ├── backup_20241226_222303.zip
    │   ├── backup_20241229_200141.zip
    │   ├── backup_20241231_010711.zip
    │   ├── backup_20250104_001127.zip
    │   ├── backup_20250123_224932.zip
    │   ├── backup_20250124_073330.zip
    │   └── backup_20250125_010647.zip
    ├── sessions
    │   └── creator.json
    └── versions
        ├── creator_0.1.39-beta.zip
        ├── creator_0.1.40-beta.zip
        └── creator_1.0.0.zip
